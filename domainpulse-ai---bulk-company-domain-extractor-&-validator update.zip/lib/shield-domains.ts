/**
 * 100+ Social Media, Directory, News, and Encyclopedia domains
 * automatically discarded to prevent false positive company domain matches.
 */
export const DEFAULT_SHIELD_DOMAINS: string[] = [
  // Major Social Media & Video
  "facebook.com",
  "instagram.com",
  "linkedin.com",
  "twitter.com",
  "x.com",
  "youtube.com",
  "tiktok.com",
  "pinterest.com",
  "reddit.com",
  "discord.com",
  "discord.gg",
  "threads.net",
  "snapchat.com",
  "tumblr.com",
  "twitch.tv",
  "vimeo.com",
  "whatsapp.com",
  "telegram.org",
  "t.me",
  "wechat.com",
  "vk.com",
  "mastodon.social",
  "bsky.app",
  "quora.com",

  // Business Directories, Review Platforms & Credit Rating
  "yelp.com",
  "yellowpages.com",
  "crunchbase.com",
  "bloomberg.com",
  "zoominfo.com",
  "pitchbook.com",
  "dnb.com",
  "trustpilot.com",
  "glassdoor.com",
  "indeed.com",
  "bbb.org",
  "opencorporates.com",
  "manta.com",
  "owler.com",
  "tripadvisor.com",
  "g2.com",
  "capterra.com",
  "getapp.com",
  "trustradius.com",
  "producthunt.com",
  "angel.co",
  "wellfound.com",
  "clutch.co",
  "upwork.com",
  "fiverr.com",
  "freelancer.com",
  "topcoder.com",
  "bark.com",
  "angi.com",
  "thumbtack.com",
  "houzz.com",
  "comparably.com",
  "zoominfo.com",
  "apollo.io",
  "lead411.com",
  "rocketreach.co",
  "lusha.com",

  // Encyclopedias, Wikis & Reference
  "wikipedia.org",
  "wikimedia.org",
  "wikihow.com",
  "britannica.com",
  "investopedia.com",
  "dictionary.com",
  "thefreedictionary.com",
  "wiktionary.org",
  "fandom.com",

  // Developer Platforms, Code & Cloud Hosting
  "github.com",
  "gitlab.com",
  "bitbucket.org",
  "sourceforge.net",
  "stackoverflow.com",
  "stackexchange.com",
  "npm.js",
  "npmjs.com",
  "pypi.org",
  "hub.docker.com",
  "vercel.app",
  "netlify.app",
  "webflow.io",
  "github.io",
  "pages.dev",
  "firebaseapp.com",
  "azurewebsites.net",
  "herokuapp.com",
  "s3.amazonaws.com",
  "blogspot.com",
  "wordpress.com",
  "wixsite.com",

  // Publishing, News, Blogs & Media
  "medium.com",
  "substack.com",
  "forbes.com",
  "techcrunch.com",
  "reuters.com",
  "cnbc.com",
  "nytimes.com",
  "wsj.com",
  "ft.com",
  "cnn.com",
  "bbc.com",
  "bbc.co.uk",
  "theguardian.com",
  "businessinsider.com",
  "marketwatch.com",
  "theverge.com",
  "wired.com",
  "engadget.com",
  "mashable.com",
  "venturebeat.com",
  "zdnet.com",
  "cnet.com",
  "fastcompany.com",
  "inc.com",
  "entrepreneur.com",

  // App Stores & Ecosystems
  "play.google.com",
  "apps.apple.com",
  "microsoft.com/store",
  "chromewebstore.google.com",
  "amazon.com",
  "ebay.com",
  "walmart.com",
  "aliexpress.com",
  "etsy.com",

  // Government & Regulatory Registries
  "sec.gov",
  "gov.uk",
  "companieshouse.gov.uk",
  "uspto.gov",
  "europa.eu",
  "whitehouse.gov",
];

// Clean root domain helper
export function extractCleanRootDomain(rawUrlOrHost?: string | null): string {
  if (!rawUrlOrHost) return "";
  let clean = rawUrlOrHost.trim().toLowerCase();

  // If it's a URL, extract hostname
  try {
    if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
      clean = "https://" + clean;
    }
    const url = new URL(clean);
    clean = url.hostname;
  } catch {
    // fallback string strip
    clean = clean.replace(/^(?:https?:\/\/)?(?:www\.)?/i, "").split("/")[0].split("?")[0].split("#")[0];
  }

  // Remove leading www.
  clean = clean.replace(/^www\./i, "");

  // Remove common port numbers if any
  clean = clean.split(":")[0];

  return clean;
}

// Check if domain matches any shield domains
export function isShieldedDomain(domain?: string | null, shieldList: string[] = DEFAULT_SHIELD_DOMAINS): boolean {
  if (!domain) return true;
  const clean = extractCleanRootDomain(domain);
  return shieldList.some((shield) => {
    const shieldClean = shield.toLowerCase().trim();
    return clean === shieldClean || clean.endsWith("." + shieldClean);
  });
}

// Corporate legal suffixes to strip for clean fuzzy matching
export const CORPORATE_SUFFIXES = [
  "inc",
  "incorporated",
  "corp",
  "corporation",
  "llc",
  "l.l.c.",
  "ltd",
  "limited",
  "pte ltd",
  "pte. ltd.",
  "pvt ltd",
  "pvt. ltd.",
  "gmbh",
  "ag",
  "s.a.",
  "sa",
  "s.a.s.",
  "sas",
  "s.r.l.",
  "srl",
  "b.v.",
  "bv",
  "n.v.",
  "nv",
  "sp. z o.o.",
  "sp zoo",
  "co.",
  "co",
  "company",
  "group",
  "holdings",
  "technologies",
  "technology",
  "solutions",
  "services",
  "global",
  "international",
  "enterprises",
  "ventures",
  "partners",
  "llp",
  "plc",
];

export function cleanCompanyNameForSearch(company: string): {
  normalized: string;
  detectedSuffix: string | null;
} {
  if (!company) return { normalized: "", detectedSuffix: null };

  let trimmed = company.trim().replace(/['"“”]/g, "");
  let detectedSuffix: string | null = null;

  for (const suffix of CORPORATE_SUFFIXES) {
    const regex = new RegExp(`\\b${suffix.replace(/\./g, "\\.")}\\b`, "i");
    if (regex.test(trimmed)) {
      detectedSuffix = suffix.toUpperCase();
      trimmed = trimmed.replace(regex, "").trim();
      break;
    }
  }

  // Remove trailing commas, hyphens, periods
  trimmed = trimmed.replace(/[,\.\-\/]+$/, "").trim();

  return {
    normalized: trimmed.length > 0 ? trimmed : company.trim(),
    detectedSuffix,
  };
}
