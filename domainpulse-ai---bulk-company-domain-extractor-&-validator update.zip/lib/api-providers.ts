export type ApiProviderId = "serper" | "google_cse" | "brightdata" | "apify" | "custom";

export interface UniversalApiConfig {
  provider: ApiProviderId;
  apiKey: string;
  // Specific to Google CSE
  googleCseId?: string;
  // Specific to Custom Endpoint
  customEndpoint?: string;
  customHttpMethod?: "GET" | "POST";
  customAuthHeader?: string; // e.g. "Authorization", "X-API-KEY", "apikey"
  customHeaderPrefix?: string; // e.g. "Bearer " or empty
  customQueryParam?: string; // e.g. "q", "query", "search"
}

export interface ApiProviderMeta {
  id: ApiProviderId;
  name: string;
  badge: string;
  description: string;
  defaultEndpoint: string;
  docsUrl: string;
  keyPlaceholder: string;
  requiresCseId?: boolean;
  requiresCustomEndpoint?: boolean;
}

export const SUPPORTED_API_PROVIDERS: Record<ApiProviderId, ApiProviderMeta> = {
  serper: {
    id: "serper",
    name: "Serper.dev",
    badge: "Recommended",
    description: "Fastest Google Search API with Knowledge Graph and organic snippet analysis (2,500 free queries).",
    defaultEndpoint: "https://google.serper.dev/search",
    docsUrl: "https://serper.dev",
    keyPlaceholder: "e.g. 78a1bc49d8e...",
  },
  google_cse: {
    id: "google_cse",
    name: "Google Custom Search JSON API",
    badge: "Official Google",
    description: "Google Cloud Programmable Search Engine API with custom search engine (cx) identification.",
    defaultEndpoint: "https://www.googleapis.com/customsearch/v1",
    docsUrl: "https://developers.google.com/custom-search/v1/overview",
    keyPlaceholder: "AIzaSy...",
    requiresCseId: true,
  },
  brightdata: {
    id: "brightdata",
    name: "Bright Data SERP API",
    badge: "Enterprise",
    description: "High-volume proxy & SERP scraping gateway with global geo-targeting.",
    defaultEndpoint: "https://api.brightdata.com/serp/req",
    docsUrl: "https://brightdata.com/products/serp-api",
    keyPlaceholder: "Bearer token / API key",
  },
  apify: {
    id: "apify",
    name: "Apify Google Scraper",
    badge: "Cloud Actor",
    description: "Apify Google Search Scraper actor runner (apify~google-search-scraper).",
    defaultEndpoint: "https://api.apify.com/v2/acts/apify~google-search-scraper/run-sync-get-dataset-items",
    docsUrl: "https://apify.com/apify/google-search-scraper",
    keyPlaceholder: "apify_api_...",
  },
  custom: {
    id: "custom",
    name: "Custom REST / Webhook API",
    badge: "Universal",
    description: "Connect your internal microservice, company scraping proxy, or any custom search API endpoint.",
    defaultEndpoint: "https://api.yourcompany.com/v1/search",
    docsUrl: "#",
    keyPlaceholder: "Bearer token or custom key",
    requiresCustomEndpoint: true,
  },
};

export const DEFAULT_UNIVERSAL_API_CONFIG: UniversalApiConfig = {
  provider: "serper",
  apiKey: "",
  googleCseId: "",
  customEndpoint: "https://api.yourcompany.com/v1/search",
  customHttpMethod: "POST",
  customAuthHeader: "Authorization",
  customHeaderPrefix: "Bearer ",
  customQueryParam: "q",
};
