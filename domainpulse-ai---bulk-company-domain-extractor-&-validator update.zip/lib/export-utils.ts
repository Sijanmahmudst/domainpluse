import * as XLSX from "xlsx";
import { ExtractedCompanyResult } from "@/app/api/domain-extract/route";

export function formatResultsForExport(results: ExtractedCompanyResult[]) {
  return results.map((r, i) => {
    const isFree = !r.extractedDomain || r.extractedDomain === "N/A";
    const creditsUsed = r.creditsUsed !== undefined ? r.creditsUsed : isFree ? 0 : 1;

    return {
      "#": i + 1,
      "Company Name": r.company,
      "Extracted Domain": r.extractedDomain || "N/A",
      "API Credits Billed": creditsUsed === 0 ? "0 (Free / Zero-Cost)" : "1 Credit",
      "Match Method":
        r.matchType === "TITLE_MATCH"
          ? "Semantic Title Match"
          : r.matchType === "EXACT_MATCH"
          ? "Exact Domain Match"
          : r.matchType === "ENRICHED_ONLY"
          ? "Enriched Contact Only"
          : r.matchType || "N/A",
      "Search Rank":
        r.matchedRank !== undefined
          ? r.matchedRank === 0
            ? "Knowledge Graph"
            : `#${r.matchedRank}`
          : "N/A",
      "Matched Page Title": r.matchedTitle || "N/A",
      Industry: r.industry || "N/A",
      "Phone Number": r.phone || "N/A",
      "Business Email": r.email || "N/A",
      Status: r.status,
      "Confidence (%)": r.confidence,
      "AI Reasoning": r.reasoning || "",
      "Source URL": r.sourceUrl || "",
    };
  });
}

/**
 * CRITICAL FIX: Exports complete CSV without data URI length truncation.
 * Uses native Blob + URL.createObjectURL and UTF-8 Byte Order Mark (\uFEFF)
 * to guarantee 100% data integrity for thousands of rows.
 */
export function exportToCSV(
  results: ExtractedCompanyResult[],
  filenamePrefix = "domainpulse_export"
) {
  if (!results || results.length === 0) return false;

  const headers = [
    "Company Name",
    "Extracted Domain",
    "API Credits Billed",
    "Match Method",
    "Matched Search Rank",
    "Matched Page Title",
    "Industry",
    "Phone Number",
    "Business Email",
    "Status",
    "Confidence %",
    "AI Reasoning",
    "Source URL",
  ];

  // Helper to safely format cell content for standard RFC 4180 CSV
  const escapeCell = (val: any) => {
    if (val === null || val === undefined) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows: string[] = [];
  // Loop through ALL items in the dataset
  for (let idx = 0; idx < results.length; idx++) {
    const r = results[idx];
    const isFree = !r.extractedDomain || r.extractedDomain === "N/A";
    const credits = r.creditsUsed !== undefined ? r.creditsUsed : isFree ? 0 : 1;
    const creditsLabel = credits === 0 ? "0 (Free / Zero-Cost)" : "1 Credit";

    const rankStr =
      r.matchedRank !== undefined
        ? r.matchedRank === 0
          ? "Knowledge Graph"
          : `#${r.matchedRank}`
        : "N/A";

    rows.push(
      [
        escapeCell(r.company),
        escapeCell(r.extractedDomain || "N/A"),
        escapeCell(creditsLabel),
        escapeCell(r.matchType || "N/A"),
        escapeCell(rankStr),
        escapeCell(r.matchedTitle || "N/A"),
        escapeCell(r.industry || "N/A"),
        escapeCell(r.phone || "N/A"),
        escapeCell(r.email || "N/A"),
        escapeCell(r.status),
        r.confidence,
        escapeCell(r.reasoning || ""),
        escapeCell(r.sourceUrl || ""),
      ].join(",")
    );
  }

  // Prepend \uFEFF Byte Order Mark for Excel UTF-8 compatibility
  const csvString = "\uFEFF" + headers.join(",") + "\r\n" + rows.join("\r\n");
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute(
    "download",
    `${filenamePrefix}_${new Date().toISOString().slice(0, 10)}.csv`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return true;
}

/**
 * Exports complete dataset to genuine Excel .xlsx using SheetJS (xlsx)
 */
export function exportToExcel(
  results: ExtractedCompanyResult[],
  filenamePrefix = "domainpulse_export"
) {
  if (!results || results.length === 0) return false;

  const exportData = formatResultsForExport(results);
  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Enriched Domains");

  // Custom column widths
  worksheet["!cols"] = [
    { wch: 6 },  // #
    { wch: 32 }, // Company Name
    { wch: 22 }, // Extracted Domain
    { wch: 20 }, // API Credits Billed
    { wch: 22 }, // Match Method
    { wch: 15 }, // Search Rank
    { wch: 35 }, // Page Title
    { wch: 28 }, // Industry
    { wch: 20 }, // Phone Number
    { wch: 26 }, // Business Email
    { wch: 12 }, // Status
    { wch: 14 }, // Confidence
    { wch: 45 }, // Reasoning
    { wch: 35 }, // Source URL
  ];

  XLSX.writeFile(
    workbook,
    `${filenamePrefix}_${new Date().toISOString().slice(0, 10)}.xlsx`
  );
  return true;
}
