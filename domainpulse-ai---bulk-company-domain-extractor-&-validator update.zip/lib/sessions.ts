import { ExtractedCompanyResult } from "@/app/api/domain-extract/route";
import { PRESET_SAMPLES } from "@/lib/presets";

export interface CompanyListSession {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  inputText: string;
  results: ExtractedCompanyResult[];
  status: "draft" | "processing" | "completed" | "paused";
  stats: {
    total: number;
    processed: number;
    verified: number;
    titleMatches: number;
    enrichedLeads: number;
    naCount: number;
    billedCredits: number;
    zeroCostSearches: number;
  };
}

const STORAGE_KEY = "domainpulse_saved_sessions";
const ACTIVE_SESSION_ID_KEY = "domainpulse_active_session_id";

export function calculateSessionStats(
  inputText: string,
  results: ExtractedCompanyResult[]
) {
  const lines = inputText
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const total = results.length > 0 ? results.length : lines.length;
  const processed = results.length;
  const verified = results.filter((r) => r.status === "VERIFIED").length;
  const titleMatches = results.filter((r) => r.matchType === "TITLE_MATCH").length;
  const enrichedLeads = results.filter(
    (r) => (r.phone && r.phone !== "N/A") || (r.email && r.email !== "N/A")
  ).length;
  const naCount = results.filter((r) => r.status === "NA").length;
  const billedCredits = results.reduce(
    (acc, r) => acc + (r.creditsUsed !== undefined ? r.creditsUsed : r.extractedDomain && r.extractedDomain !== "N/A" ? 1 : 0),
    0
  );
  const zeroCostSearches = results.filter(
    (r) => r.creditsUsed === 0 || (!r.extractedDomain || r.extractedDomain === "N/A")
  ).length;

  return {
    total,
    processed,
    verified,
    titleMatches,
    enrichedLeads,
    naCount,
    billedCredits,
    zeroCostSearches,
  };
}

export function createNewSession(
  customName?: string,
  initialText?: string,
  initialResults: ExtractedCompanyResult[] = []
): CompanyListSession {
  const timestamp = Date.now();
  const dateFormatted = new Date(timestamp).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const text = initialText !== undefined ? initialText : PRESET_SAMPLES[0].companies.join("\n");
  const count = text.split("\n").filter((l) => l.trim().length > 0).length;
  const name = customName || `Batch List (${count} Cos) - ${dateFormatted}`;

  return {
    id: `session_${timestamp}_${Math.random().toString(36).substring(2, 7)}`,
    name,
    createdAt: timestamp,
    updatedAt: timestamp,
    inputText: text,
    results: initialResults,
    status: initialResults.length > 0 ? "completed" : "draft",
    stats: calculateSessionStats(text, initialResults),
  };
}

export function loadSavedSessions(): CompanyListSession[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error("Failed to parse saved sessions from localStorage:", err);
  }

  // Bootstrap initial sample session
  const defaultSession = createNewSession(
    "List #1 - Semantic Titles Benchmark",
    PRESET_SAMPLES[0].companies.join("\n")
  );
  saveSessionsToStorage([defaultSession]);
  return [defaultSession];
}

export function saveSessionsToStorage(sessions: CompanyListSession[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  } catch (err) {
    console.error("Failed to save sessions to localStorage:", err);
  }
}

export function getActiveSessionId(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(ACTIVE_SESSION_ID_KEY);
}

export function setActiveSessionIdInStorage(id: string): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(ACTIVE_SESSION_ID_KEY, id);
}
