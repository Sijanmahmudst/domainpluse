import { NextRequest, NextResponse } from "next/server";
import { UniversalApiConfig } from "@/lib/api-providers";

export async function POST(req: NextRequest) {
  const start = Date.now();
  try {
    const config = (await req.json()) as UniversalApiConfig;
    const provider = config.provider || "serper";
    const apiKey = (config.apiKey || "").trim();

    if (!apiKey) {
      return NextResponse.json(
        { valid: false, message: "Please provide an API Key / Token." },
        { status: 400 }
      );
    }

    if (provider === "serper") {
      const testRes = await fetch("https://google.serper.dev/search", {
        method: "POST",
        headers: {
          "X-API-KEY": apiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          q: "Google official site",
          num: 1,
        }),
      });

      const latency = Date.now() - start;

      if (testRes.status === 401 || testRes.status === 403) {
        return NextResponse.json(
          { valid: false, message: "Invalid Serper API Key (Unauthorized).", latency },
          { status: 401 }
        );
      }

      if (!testRes.ok) {
        const err = await testRes.text();
        return NextResponse.json(
          { valid: false, message: `Serper error ${testRes.status}: ${err}`, latency },
          { status: testRes.status }
        );
      }

      const data = await testRes.json();
      const credits = data.credits ?? undefined;

      return NextResponse.json({
        valid: true,
        provider: "Serper.dev",
        message: "Serper.dev Google API connected successfully!",
        latency,
        credits,
      });
    }

    if (provider === "google_cse") {
      const cseId = (config.googleCseId || "").trim();
      if (!cseId) {
        return NextResponse.json(
          { valid: false, message: "Google Custom Search Engine ID (cx) is required." },
          { status: 400 }
        );
      }

      const url = `https://www.googleapis.com/customsearch/v1?key=${encodeURIComponent(
        apiKey
      )}&cx=${encodeURIComponent(cseId)}&q=Google&num=1`;

      const testRes = await fetch(url);
      const latency = Date.now() - start;

      if (!testRes.ok) {
        const errData = await testRes.json().catch(() => ({}));
        const errMsg = errData.error?.message || `HTTP ${testRes.status}`;
        return NextResponse.json(
          { valid: false, message: `Google CSE error: ${errMsg}`, latency },
          { status: testRes.status }
        );
      }

      const data = await testRes.json();
      const itemsCount = data.items?.length || 0;

      return NextResponse.json({
        valid: true,
        provider: "Google Custom Search",
        message: `Google CSE connected successfully (${itemsCount} candidate returned).`,
        latency,
      });
    }

    if (provider === "brightdata") {
      const endpoint = config.customEndpoint || "https://api.brightdata.com/serp/req";
      const testRes = await fetch(endpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: { q: "Google official site", num: 1 },
        }),
      }).catch((e) => ({ ok: false, status: 500, statusText: e.message }));

      const latency = Date.now() - start;
      return NextResponse.json({
        valid: true,
        provider: "Bright Data",
        message: "Bright Data SERP API endpoint reached.",
        latency,
      });
    }

    if (provider === "apify") {
      const testRes = await fetch(
        `https://api.apify.com/v2/users/me?token=${encodeURIComponent(apiKey)}`
      );
      const latency = Date.now() - start;

      if (!testRes.ok) {
        return NextResponse.json(
          { valid: false, message: "Invalid Apify API token.", latency },
          { status: testRes.status }
        );
      }

      const userData = await testRes.json().catch(() => ({}));
      const username = userData.data?.username || "Authenticated";

      return NextResponse.json({
        valid: true,
        provider: "Apify",
        message: `Apify connected as @${username}!`,
        latency,
      });
    }

    if (provider === "custom") {
      const endpoint = (config.customEndpoint || "").trim();
      if (!endpoint) {
        return NextResponse.json(
          { valid: false, message: "Custom endpoint URL is required." },
          { status: 400 }
        );
      }

      const headerName = config.customAuthHeader || "Authorization";
      const headerPrefix = config.customHeaderPrefix !== undefined ? config.customHeaderPrefix : "Bearer ";
      const method = config.customHttpMethod || "POST";

      const headers: Record<string, string> = {
        [headerName]: `${headerPrefix}${apiKey}`,
        "Content-Type": "application/json",
      };

      const testRes = await fetch(endpoint, {
        method,
        headers,
        body:
          method === "POST"
            ? JSON.stringify({
                [config.customQueryParam || "q"]: "Google official site",
              })
            : undefined,
      }).catch((e) => ({ ok: false, status: 500, statusText: e.message }));

      const latency = Date.now() - start;

      return NextResponse.json({
        valid: testRes.ok !== false,
        provider: "Custom API Endpoint",
        message: `Custom endpoint responded with status ${(testRes as any).status || 200}`,
        latency,
      });
    }

    return NextResponse.json(
      { valid: false, message: `Unknown provider: ${provider}` },
      { status: 400 }
    );
  } catch (err: any) {
    const latency = Date.now() - start;
    return NextResponse.json(
      { valid: false, message: err?.message || "Failed to reach API Provider", latency },
      { status: 500 }
    );
  }
}
