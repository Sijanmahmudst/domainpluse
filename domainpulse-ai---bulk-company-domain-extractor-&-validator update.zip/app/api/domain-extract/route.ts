import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";
import {
  extractCleanRootDomain,
  isShieldedDomain,
  cleanCompanyNameForSearch,
  DEFAULT_SHIELD_DOMAINS,
} from "@/lib/shield-domains";
import { UniversalApiConfig } from "@/lib/api-providers";

export interface SearchCandidate {
  rank: number;
  title: string;
  link: string;
  snippet: string;
  cleanDomain: string;
  isShielded: boolean;
}

export type MatchType = "EXACT_MATCH" | "TITLE_MATCH" | "ENRICHED_ONLY" | "NA";

export interface ExtractedCompanyResult {
  company: string;
  extractedDomain: string;
  creditsUsed: number; // 1 for verified domain, 0 for N/A (Zero-Cost Dashboard Policy)
  industry: string;
  phone: string;
  email: string;
  status: "VERIFIED" | "PARTIAL" | "NA";
  matchType: MatchType;
  matchedRank?: number;
  matchedTitle?: string;
  confidence: number;
  reasoning: string;
  sourceUrl?: string;
  serperSnippet?: string;
  candidatesEvaluated: number;
  fromLiveSerper: boolean;
}

// Function to call Serper API strictly ONCE per company (1 Credit = 1 Company Optimization)
// Multi-result deep domain search (num: 10) + Knowledge Graph & contact snippets extracted from a SINGLE payload
async function fetchSerperSingleRequestPayload(
  company: string,
  apiKey: string
): Promise<{ candidates: SearchCandidate[]; enrichmentSnippets: string[]; knowledgeGraph?: any }> {
  try {
    const { normalized } = cleanCompanyNameForSearch(company);
    const query = `${normalized} official website`;

    const res = await fetch("https://google.serper.dev/search", {
      method: "POST",
      headers: {
        "X-API-KEY": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        q: query,
        num: 10, // Multi-result deep scanning beyond top 1 (strictly 1 search request)
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.warn(`Serper API error for "${company}": ${res.status} ${errText}`);
      return { candidates: [], enrichmentSnippets: [] };
    }

    const data = await res.json();
    const candidates: SearchCandidate[] = [];
    const enrichmentSnippets: string[] = [];

    // Check Google Knowledge Graph for website & corporate attributes
    if (data.knowledgeGraph) {
      const kg = data.knowledgeGraph;
      const rawKgWebsite = kg.website;
      if (typeof rawKgWebsite === "string" && rawKgWebsite.trim().length > 0) {
        const kgWebsite = rawKgWebsite.trim();
        const cleanKgDomain = extractCleanRootDomain(kgWebsite);
        if (cleanKgDomain && !isShieldedDomain(cleanKgDomain)) {
          candidates.push({
            rank: 0, // Knowledge Graph has top authority
            title: kg.title || `${company} (Official Knowledge Graph)`,
            link: kgWebsite,
            snippet: `Google Knowledge Graph primary corporate entity. Type: ${kg.type || "Corporate"}. Phone: ${kg.phone || "N/A"}.`,
            cleanDomain: cleanKgDomain,
            isShielded: false,
          });
        }
      }

      // Simultaneously harvest contact & industry signals from Knowledge Graph without secondary API call
      const kgDetails: string[] = [];
      if (kg.type) kgDetails.push(`Industry/Type: ${kg.type}`);
      if (kg.phone) kgDetails.push(`Phone: ${kg.phone}`);
      if (kg.headquarters || kg.address) kgDetails.push(`Headquarters: ${kg.headquarters || kg.address}`);
      if (kg.customerService) kgDetails.push(`Customer Service: ${kg.customerService}`);
      if (kgDetails.length > 0) {
        enrichmentSnippets.push(`[Google Knowledge Graph] ${kgDetails.join(" | ")}`);
      }
    }

    // Parse up to 10 organic results for domain candidates & contextual snippets
    if (Array.isArray(data.organic)) {
      data.organic.forEach((item: any, idx: number) => {
        if (!item.link) return;
        const clean = extractCleanRootDomain(item.link);
        const shielded = isShieldedDomain(clean);
        candidates.push({
          rank: idx + 1,
          title: item.title || "",
          link: item.link,
          snippet: item.snippet || "",
          cleanDomain: clean,
          isShielded: shielded,
        });

        // Harvest snippet text for simultaneous Gemini contact & industry extraction
        if (item.snippet) {
          enrichmentSnippets.push(`[${item.title || "Organic Result"}] ${item.snippet}`);
        }
      });
    }

    return { candidates, enrichmentSnippets, knowledgeGraph: data.knowledgeGraph };
  } catch (err) {
    console.error(`Failed to fetch single Serper payload for ${company}:`, err);
    return { candidates: [], enrichmentSnippets: [] };
  }
}

// Realistic multi-result simulation database for non-matching slugs (testing semantic title matching)
const KNOWN_DEEP_SEARCH_DATABASE: Record<
  string,
  {
    domain: string;
    industry: string;
    phone: string;
    email: string;
    candidates: Array<{ rank: number; title: string; link: string; snippet: string; cleanDomain: string; isShielded: boolean }>;
  }
> = {
  alphabet: {
    domain: "abc.xyz",
    industry: "Technology Conglomerate & Holding",
    phone: "+1 (650) 253-0000",
    email: "press@abc.xyz",
    candidates: [
      {
        rank: 1,
        title: "Alphabet - Investor Relations and Corporate Portal",
        link: "https://abc.xyz/",
        snippet: "Alphabet Inc. is a multinational technology conglomerate holding company created through a restructuring of Google. Explore corporate leadership, investor relations, and financial reports.",
        cleanDomain: "abc.xyz",
        isShielded: false,
      },
      {
        rank: 2,
        title: "Alphabet Inc. - Wikipedia",
        link: "https://en.wikipedia.org/wiki/Alphabet_Inc.",
        snippet: "Alphabet Inc. is an American multinational technology conglomerate holding company headquartered in Mountain View, California.",
        cleanDomain: "wikipedia.org",
        isShielded: true,
      },
      {
        rank: 3,
        title: "Google About - Our Products & Company",
        link: "https://about.google/",
        snippet: "Our mission is to organize the world's information and make it universally accessible and useful.",
        cleanDomain: "about.google",
        isShielded: false,
      },
    ],
  },
  meta: {
    domain: "meta.com",
    industry: "Social Technology & Metaverse",
    phone: "+1 (650) 543-4800",
    email: "press@meta.com",
    candidates: [
      {
        rank: 1,
        title: "Meta Platforms | Building the Future of Connection",
        link: "https://about.meta.com/",
        snippet: "Meta Platforms, Inc. builds technologies that help people connect, find communities, and grow businesses. Formerly known as Facebook, Inc.",
        cleanDomain: "about.meta.com",
        isShielded: false,
      },
      {
        rank: 2,
        title: "Meta - Shop VR Headsets and Smart Glasses",
        link: "https://www.meta.com/",
        snippet: "Experience Meta Quest virtual reality headsets and Ray-Ban Meta smart glasses on the official Meta website.",
        cleanDomain: "meta.com",
        isShielded: false,
      },
    ],
  },
  caterpillar: {
    domain: "cat.com",
    industry: "Heavy Machinery & Construction",
    phone: "+1 (309) 675-1000",
    email: "cat_support@cat.com",
    candidates: [
      {
        rank: 1,
        title: "Caterpillar | Cat | Global Heavy Equipment & Power Systems",
        link: "https://www.cat.com/",
        snippet: "Caterpillar is the world's leading manufacturer of construction and mining equipment, diesel and natural gas engines, industrial gas turbines and locomotives.",
        cleanDomain: "cat.com",
        isShielded: false,
      },
    ],
  },
  americanairlines: {
    domain: "aa.com",
    industry: "Airlines & Aviation",
    phone: "+1 (800) 433-7300",
    email: "customer.relations@aa.com",
    candidates: [
      {
        rank: 1,
        title: "American Airlines - Airline tickets and cheap flights at aa.com",
        link: "https://www.aa.com/",
        snippet: "Book low fares to destinations around the world and find the best flight deals on American Airlines official homepage.",
        cleanDomain: "aa.com",
        isShielded: false,
      },
    ],
  },
  kraftheinz: {
    domain: "kraftheinzcompany.com",
    industry: "Food & Beverage Manufacturing",
    phone: "+1 (800) 323-0768",
    email: "consumer.affairs@kraftheinz.com",
    candidates: [
      {
        rank: 1,
        title: "The Kraft Heinz Company | Official Corporate Website",
        link: "https://www.kraftheinzcompany.com/",
        snippet: "The Kraft Heinz Company is one of the largest food and beverage companies in the world, with iconic brands including Kraft, Heinz, Oscar Mayer, and Philadelphia.",
        cleanDomain: "kraftheinzcompany.com",
        isShielded: false,
      },
    ],
  },
  lvmh: {
    domain: "lvmh.com",
    industry: "Luxury Goods & Fashion",
    phone: "+33 1 44 13 22 22",
    email: "contact@lvmh.com",
    candidates: [
      {
        rank: 1,
        title: "LVMH - World Leader in Luxury & Creative Craftsmanship",
        link: "https://www.lvmh.com/",
        snippet: "LVMH Moët Hennessy Louis Vuitton gathers 75 prestigious Maisons in Wines & Spirits, Fashion & Leather Goods, Perfumes & Cosmetics, Watches & Jewelry.",
        cleanDomain: "lvmh.com",
        isShielded: false,
      },
    ],
  },
  kfc: {
    domain: "kfc.com",
    industry: "Fast Food & Restaurants",
    phone: "+1 (800) 225-5532",
    email: "support@kfc.com",
    candidates: [
      {
        rank: 1,
        title: "KFC - Finger Lickin' Good Fried Chicken",
        link: "https://www.kfc.com/",
        snippet: "Order delicious fried chicken online, find a KFC near you, browse the menu, and order pickup or delivery on the official KFC website.",
        cleanDomain: "kfc.com",
        isShielded: false,
      },
    ],
  },
  pmi: {
    domain: "pmi.com",
    industry: "Consumer Goods & Tobacco",
    phone: "+41 58 242 00 00",
    email: "media@pmi.com",
    candidates: [
      {
        rank: 1,
        title: "Philip Morris International | Delivering a Smoke-Free Future",
        link: "https://www.pmi.com/",
        snippet: "Philip Morris International (PMI) is leading a transformation in the tobacco industry to create a smoke-free future.",
        cleanDomain: "pmi.com",
        isShielded: false,
      },
    ],
  },
};

// Simulated search candidate generator for demo mode
function simulateMultiResultCandidates(company: string): {
  candidates: SearchCandidate[];
  enrichmentSnippets: string[];
} {
  const { normalized } = cleanCompanyNameForSearch(company);
  const stem = normalized.toLowerCase().replace(/[^a-z0-9]/g, "");

  // Check known deep search database
  for (const [key, entry] of Object.entries(KNOWN_DEEP_SEARCH_DATABASE)) {
    if (stem.includes(key) || key.includes(stem)) {
      return {
        candidates: entry.candidates,
        enrichmentSnippets: [
          `Corporate Headquarters Registry: ${normalized}. Industry: ${entry.industry}. Telephone: ${entry.phone}. Business Email: ${entry.email}.`,
        ],
      };
    }
  }

  // General simulated top 5 candidates with diverse page titles
  const slug = stem;
  return {
    candidates: [
      {
        rank: 1,
        title: `${normalized} | Official Company Portal & Solutions`,
        link: `https://www.${slug}.com/`,
        snippet: `Welcome to the official website of ${normalized}. Discover products, enterprise technology, investor disclosures, and corporate operations.`,
        cleanDomain: `${slug}.com`,
        isShielded: false,
      },
      {
        rank: 2,
        title: `${normalized} - LinkedIn Corporate Profile`,
        link: `https://www.linkedin.com/company/${slug}`,
        snippet: `Follow ${normalized} on LinkedIn to view jobs, business news, and team updates.`,
        cleanDomain: "linkedin.com",
        isShielded: true,
      },
      {
        rank: 3,
        title: `${normalized} - Wikipedia`,
        link: `https://en.wikipedia.org/wiki/${encodeURIComponent(normalized)}`,
        snippet: `${normalized} is a corporation founded in...`,
        cleanDomain: "wikipedia.org",
        isShielded: true,
      },
      {
        rank: 4,
        title: `Working at ${normalized} | Glassdoor Reviews`,
        link: `https://www.glassdoor.com/Overview/${slug}`,
        snippet: `Read employee reviews, company culture, and salary ranges for ${normalized}.`,
        cleanDomain: "glassdoor.com",
        isShielded: true,
      },
    ],
    enrichmentSnippets: [
      `Official Profile for ${normalized}: Primary Industry: Commercial & Business Services. General contact: info@${slug}.com. Telephone hotline: +1 (800) 555-0199.`,
    ],
  };
}

// Universal provider dispatcher supporting Serper, Google CSE, Bright Data, Apify, and Custom APIs
async function fetchUniversalSearchResults(
  company: string,
  apiConfig?: UniversalApiConfig | null,
  legacySerperApiKey?: string,
  enableEnrichment = true
): Promise<{
  candidates: SearchCandidate[];
  knowledgeGraph?: any;
  enrichmentSnippets: string[];
  isLive: boolean;
}> {
  const config =
    apiConfig && apiConfig.apiKey?.trim().length > 0
      ? apiConfig
      : legacySerperApiKey && legacySerperApiKey.trim().length > 5
      ? ({ provider: "serper" as const, apiKey: legacySerperApiKey.trim() } as UniversalApiConfig)
      : null;

  if (!config || !config.apiKey || config.apiKey.trim().length === 0) {
    const sim = simulateMultiResultCandidates(company);
    return {
      candidates: sim.candidates,
      enrichmentSnippets: sim.enrichmentSnippets,
      isLive: false,
    };
  }

  const { normalized } = cleanCompanyNameForSearch(company);

  // 1. Serper.dev Google Search API (Strict Single-Request Policy: 1 Credit = 1 Company Optimization)
  if (config.provider === "serper") {
    const singleRes = await fetchSerperSingleRequestPayload(company, config.apiKey.trim());
    return {
      candidates: singleRes.candidates,
      knowledgeGraph: singleRes.knowledgeGraph,
      enrichmentSnippets: singleRes.enrichmentSnippets,
      isLive: true,
    };
  }

  // 2. Google Custom Search JSON API (CSE)
  if (config.provider === "google_cse") {
    try {
      const cseId = config.googleCseId || "";
      const query = `${normalized} official website`;
      const url = `https://www.googleapis.com/customsearch/v1?key=${encodeURIComponent(
        config.apiKey.trim()
      )}&cx=${encodeURIComponent(cseId)}&num=10&q=${encodeURIComponent(query)}`;

      const res = await fetch(url);
      if (!res.ok) {
        console.warn(`Google CSE search returned HTTP ${res.status} for "${company}"`);
        const sim = simulateMultiResultCandidates(company);
        return { candidates: sim.candidates, enrichmentSnippets: sim.enrichmentSnippets, isLive: false };
      }

      const data = await res.json();
      const candidates: SearchCandidate[] = [];
      const snippets: string[] = [];

      if (Array.isArray(data.items)) {
        data.items.forEach((item: any, idx: number) => {
          if (!item.link) return;
          const clean = extractCleanRootDomain(item.link);
          const shielded = isShieldedDomain(clean);
          candidates.push({
            rank: idx + 1,
            title: item.title || "",
            link: item.link,
            snippet: item.snippet || "",
            cleanDomain: clean,
            isShielded: shielded,
          });
          if (item.snippet) {
            snippets.push(`[${item.title || "Search Result"}] ${item.snippet}`);
          }
        });
      }

      return { candidates, enrichmentSnippets: snippets, isLive: true };
    } catch (err) {
      console.error(`Google CSE fetch error for ${company}:`, err);
      const sim = simulateMultiResultCandidates(company);
      return { candidates: sim.candidates, enrichmentSnippets: sim.enrichmentSnippets, isLive: false };
    }
  }

  // 3. Custom REST or Webhook Endpoint
  if (config.provider === "custom") {
    try {
      const endpoint = config.customEndpoint || "https://api.yourcompany.com/v1/search";
      const headerName = config.customAuthHeader || "Authorization";
      const headerPrefix =
        config.customHeaderPrefix !== undefined ? config.customHeaderPrefix : "Bearer ";
      const method = config.customHttpMethod || "POST";
      const queryParam = config.customQueryParam || "q";
      const query = `${normalized} official website`;

      const headers: Record<string, string> = {
        [headerName]: `${headerPrefix}${config.apiKey.trim()}`,
        "Content-Type": "application/json",
      };

      const url =
        method === "GET"
          ? `${endpoint}${endpoint.includes("?") ? "&" : "?"}${encodeURIComponent(
              queryParam
            )}=${encodeURIComponent(query)}`
          : endpoint;

      const res = await fetch(url, {
        method,
        headers,
        body:
          method === "POST"
            ? JSON.stringify({ [queryParam]: query, num: 10, limit: 10 })
            : undefined,
      });

      if (!res.ok) {
        const sim = simulateMultiResultCandidates(company);
        return { candidates: sim.candidates, enrichmentSnippets: sim.enrichmentSnippets, isLive: false };
      }

      const data = await res.json();
      const items = Array.isArray(data.items)
        ? data.items
        : Array.isArray(data.organic)
        ? data.organic
        : Array.isArray(data.results)
        ? data.results
        : Array.isArray(data.data)
        ? data.data
        : [];

      const candidates: SearchCandidate[] = [];
      const snippets: string[] = [];

      items.slice(0, 10).forEach((item: any, idx: number) => {
        const link = item.link || item.url || "";
        if (!link) return;
        const clean = extractCleanRootDomain(link);
        candidates.push({
          rank: idx + 1,
          title: item.title || "",
          link,
          snippet: item.snippet || item.description || "",
          cleanDomain: clean,
          isShielded: isShieldedDomain(clean),
        });
        if (item.snippet || item.description) {
          snippets.push(`[${item.title || ""}] ${item.snippet || item.description}`);
        }
      });

      return { candidates, enrichmentSnippets: snippets, isLive: true };
    } catch (err) {
      console.error(`Custom API provider error for ${company}:`, err);
      const sim = simulateMultiResultCandidates(company);
      return { candidates: sim.candidates, enrichmentSnippets: sim.enrichmentSnippets, isLive: false };
    }
  }

  // 4. Default fallback
  const sim = simulateMultiResultCandidates(company);
  return { candidates: sim.candidates, enrichmentSnippets: sim.enrichmentSnippets, isLive: false };
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      companies,
      serperApiKey,
      apiConfig,
      customGeminiApiKey,
      strictness = 70, // percentage threshold
      customShieldDomains,
      enableEnrichment = true,
    } = body as {
      companies: string[];
      serperApiKey?: string;
      apiConfig?: UniversalApiConfig;
      customGeminiApiKey?: string;
      strictness?: number;
      customShieldDomains?: string[];
      enableEnrichment?: boolean;
    };

    if (!companies || !Array.isArray(companies) || companies.length === 0) {
      return NextResponse.json(
        { error: "Please provide an array of company names." },
        { status: 400 }
      );
    }

    // Limit batch per single request to 25 items for latency and quota safety
    const batchToProcess = companies.slice(0, 25);

    // Active shield list
    const activeShield =
      customShieldDomains && Array.isArray(customShieldDomains)
        ? customShieldDomains
        : DEFAULT_SHIELD_DOMAINS;

    // Initialize Gemini AI
    const geminiKey = customGeminiApiKey || process.env.GEMINI_API_KEY;
    let aiClient: GoogleGenAI | null = null;
    if (geminiKey) {
      aiClient = new GoogleGenAI({
        apiKey: geminiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }

    // 1. Gather Deep Multi-Result Universal Search or Simulated search results
    const searchDataPerCompany = await Promise.all(
      batchToProcess.map(async (rawComp) => {
        const comp = rawComp.trim();
        if (!comp) {
          return {
            company: rawComp,
            candidates: [],
            validCandidates: [],
            enrichmentSnippets: [],
            fromLiveSerper: false,
          };
        }

        const providerSearch = await fetchUniversalSearchResults(
          comp,
          apiConfig,
          serperApiKey,
          enableEnrichment
        );

        const valid = providerSearch.candidates.filter(
          (c) => !isShieldedDomain(c.cleanDomain, activeShield)
        );

        return {
          company: comp,
          candidates: providerSearch.candidates,
          validCandidates: valid,
          enrichmentSnippets: providerSearch.enrichmentSnippets,
          fromLiveSerper: providerSearch.isLive,
        };
      })
    );

    // 2. Build structured validation & title semantic matching task for Gemini AI
    const validationItems = searchDataPerCompany.map((item) => {
      const { normalized, detectedSuffix } = cleanCompanyNameForSearch(item.company);
      const candidatesClean = item.validCandidates.map((c) => ({
        rank: c.rank,
        domain: c.cleanDomain,
        url: c.link,
        pageTitle: c.title,
        snippet: c.snippet,
      }));

      return {
        company: item.company,
        normalizedName: normalized,
        detectedLegalSuffix: detectedSuffix,
        searchCandidates: candidatesClean,
        enrichmentSnippets: item.enrichmentSnippets,
      };
    });

    // 3. Smart Semantic Title & Snippet Analysis via Gemini AI
    let aiResultsMap: Record<
      string,
      {
        domain: string;
        industry: string;
        phone: string;
        email: string;
        status: "VERIFIED" | "PARTIAL" | "NA";
        matchType: MatchType;
        matchedRank: number;
        matchedTitle: string;
        confidence: number;
        reasoning: string;
      }
    > = {};

    if (aiClient) {
      try {
        const prompt = `You are DomainPulse AI, an expert deep-search semantic matcher and corporate entity verification engine.
Analyze multiple Google Search candidates (including Page Titles, Snippets, URLs, and Rank) to find the authentic official corporate website for each company, even when the domain name does not directly match the company name.

CRITICAL DEEP-SEARCH & SEMANTIC TITLE RULES:
1. DO NOT rely solely on the domain slug. Look deeply at the Page Title, Meta Description, and Snippet semantics:
   - For example: "Alphabet Inc." official website is "abc.xyz" (Title: "Alphabet - Investor Relations").
   - "Meta Platforms, Inc." is "meta.com" or "about.meta.com".
   - "Caterpillar Inc." is "cat.com".
   - "American Airlines Group" is "aa.com".
   - "LVMH" is "lvmh.com".
   - "Kraft Heinz Company" is "kraftheinzcompany.com".
   - If a candidate's Page Title or Snippet contextually proves it is the official corporate homepage or holding entity of the target company, select that domain even if it ranks at position 2, 3, or has an abbreviated domain name!
2. DOMAIN CLEANING: Return clean root domain ONLY (e.g. "abc.xyz", "meta.com", "cat.com"). No "https://", no "www.", no path. If no authentic corporate website is found among the search results, set domain to "N/A".
3. MATCH TYPE:
   - "EXACT_MATCH": The domain slug directly matches the company name/brand (e.g., Apple -> apple.com).
   - "TITLE_MATCH": The domain slug is abbreviated, distinct, or belongs to a parent/subsidiary, but the Page Title / Snippet explicitly confirms it is the company's authentic website (e.g. Alphabet -> abc.xyz, Caterpillar -> cat.com, American Airlines -> aa.com).
   - "ENRICHED_ONLY": No reliable corporate domain was found, but reliable Industry, Phone, or Email was verified from authoritative corporate profile snippets.
   - "NA": No authentic domain or verified data could be matched.
4. MATCHED RANK: Specify the integer rank of the selected candidate (e.g. 1, 2, 3...). If Knowledge Graph, use 0. If none, use -1.
5. FALLBACK CONTACT ENRICHMENT:
   - Extract verified primary Industry/Sector (e.g. "Technology Conglomerate", "Automotive", "Food & Beverage").
   - Extract official corporate Headquarters or customer phone number (with country code). STRICT: NEVER extract directory phone numbers (Yelp, YellowPages, BBB, ZoomInfo).
   - Extract official business email (info@, contact@, press@). STRICT: NEVER extract directory emails (support@yelp.com, privacy@crunchbase.com).
   - If not found with certainty, set to "N/A".

Companies and deep search candidates:
${JSON.stringify(validationItems, null, 2)}`;

        const response = await aiClient.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                evaluations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      company: { type: Type.STRING },
                      domain: { type: Type.STRING },
                      industry: { type: Type.STRING },
                      phone: { type: Type.STRING },
                      email: { type: Type.STRING },
                      status: { type: Type.STRING },
                      matchType: { type: Type.STRING },
                      matchedRank: { type: Type.INTEGER },
                      matchedTitle: { type: Type.STRING },
                      confidence: { type: Type.INTEGER },
                      reasoning: { type: Type.STRING },
                    },
                    required: [
                      "company",
                      "domain",
                      "industry",
                      "phone",
                      "email",
                      "status",
                      "matchType",
                      "matchedRank",
                      "matchedTitle",
                      "confidence",
                      "reasoning",
                    ],
                  },
                },
              },
              required: ["evaluations"],
            },
          },
        });

        const text = response.text;
        if (text) {
          const parsed = JSON.parse(text);
          if (parsed.evaluations && Array.isArray(parsed.evaluations)) {
            for (const evalItem of parsed.evaluations) {
              const cleanedDomain = extractCleanRootDomain(evalItem.domain);
              const statusVal =
                evalItem.status === "VERIFIED"
                  ? "VERIFIED"
                  : evalItem.status === "PARTIAL"
                  ? "PARTIAL"
                  : "NA";

              const matchTypeVal: MatchType =
                evalItem.matchType === "EXACT_MATCH"
                  ? "EXACT_MATCH"
                  : evalItem.matchType === "TITLE_MATCH"
                  ? "TITLE_MATCH"
                  : evalItem.matchType === "ENRICHED_ONLY"
                  ? "ENRICHED_ONLY"
                  : "NA";

              aiResultsMap[evalItem.company.toLowerCase().trim()] = {
                domain: cleanedDomain || "N/A",
                industry: evalItem.industry?.trim() || "N/A",
                phone: evalItem.phone?.trim() || "N/A",
                email: evalItem.email?.trim() || "N/A",
                status: statusVal,
                matchType: matchTypeVal,
                matchedRank: Number(evalItem.matchedRank) ?? 1,
                matchedTitle: evalItem.matchedTitle?.trim() || "",
                confidence: Number(evalItem.confidence) || 0,
                reasoning: evalItem.reasoning || "Evaluated via semantic title matching",
              };
            }
          }
        }
      } catch (geminiErr) {
        console.warn("Gemini validation call error, falling back to heuristic validator:", geminiErr);
      }
    }

    // 4. Assemble final results
    const finalResults: ExtractedCompanyResult[] = searchDataPerCompany.map((item) => {
      const lowerComp = item.company.toLowerCase().trim();
      const aiEval = aiResultsMap[lowerComp];

      // If AI gave a structured evaluation
      if (aiEval) {
        const domainValid =
          aiEval.domain !== "N/A" &&
          aiEval.confidence >= strictness &&
          !isShieldedDomain(aiEval.domain, activeShield);

        const hasContactInfo =
          aiEval.phone !== "N/A" ||
          aiEval.email !== "N/A" ||
          (aiEval.industry !== "N/A" && aiEval.industry !== "Unknown");

        let status: "VERIFIED" | "PARTIAL" | "NA" = "NA";
        if (domainValid && hasContactInfo) {
          status = "VERIFIED";
        } else if (domainValid || hasContactInfo) {
          status = "PARTIAL";
        }

        let matchType: MatchType = aiEval.matchType;
        if (!domainValid && hasContactInfo) {
          matchType = "ENRICHED_ONLY";
        } else if (!domainValid && !hasContactInfo) {
          matchType = "NA";
        }

        const candidateMatch = item.validCandidates.find(
          (c) => c.cleanDomain === aiEval.domain
        );

        const creditsUsed = domainValid ? 1 : 0;

        return {
          company: item.company,
          extractedDomain: domainValid ? aiEval.domain : "N/A",
          creditsUsed,
          industry: aiEval.industry || "N/A",
          phone: aiEval.phone || "N/A",
          email: aiEval.email || "N/A",
          status,
          matchType,
          matchedRank: candidateMatch?.rank ?? (aiEval.matchedRank > 0 ? aiEval.matchedRank : undefined),
          matchedTitle: candidateMatch?.title || aiEval.matchedTitle || undefined,
          confidence: aiEval.confidence,
          reasoning: aiEval.reasoning,
          sourceUrl: candidateMatch?.link || (domainValid ? `https://${aiEval.domain}` : undefined),
          serperSnippet: candidateMatch?.snippet || item.enrichmentSnippets[0],
          candidatesEvaluated: item.candidates.length,
          fromLiveSerper: item.fromLiveSerper,
        };
      }

      // Fallback heuristic if Gemini was offline
      if (item.validCandidates.length > 0) {
        const topCandidate = item.validCandidates[0];
        const clean = topCandidate.cleanDomain;
        const { normalized } = cleanCompanyNameForSearch(item.company);
        const normLower = normalized.toLowerCase().replace(/[^a-z0-9]/g, "");
        const domLower = clean.toLowerCase().replace(/[^a-z0-9]/g, "");
        const titleLower = topCandidate.title.toLowerCase();

        const isExactMatch = domLower.includes(normLower);
        const isTitleMatch = titleLower.includes(normalized.toLowerCase()) || titleLower.includes(normLower);
        const isVerified = (isExactMatch || isTitleMatch) && 80 >= strictness;

        const matchType: MatchType = isExactMatch
          ? "EXACT_MATCH"
          : isTitleMatch
          ? "TITLE_MATCH"
          : "NA";

        const creditsUsed = isVerified ? 1 : 0;

        return {
          company: item.company,
          extractedDomain: isVerified ? clean : "N/A",
          creditsUsed,
          industry: "Commercial & Business Services",
          phone: "N/A",
          email: "N/A",
          status: isVerified ? "PARTIAL" : "NA",
          matchType: isVerified ? matchType : "NA",
          matchedRank: topCandidate.rank,
          matchedTitle: topCandidate.title,
          confidence: isExactMatch ? 90 : isTitleMatch ? 82 : 40,
          reasoning: isTitleMatch
            ? `Page title "${topCandidate.title}" semantically verified entity match at rank #${topCandidate.rank}`
            : "Direct candidate match",
          sourceUrl: topCandidate.link,
          serperSnippet: topCandidate.snippet,
          candidatesEvaluated: item.candidates.length,
          fromLiveSerper: item.fromLiveSerper,
        };
      }

      return {
        company: item.company,
        extractedDomain: "N/A",
        creditsUsed: 0,
        industry: "N/A",
        phone: "N/A",
        email: "N/A",
        status: "NA",
        matchType: "NA",
        confidence: 0,
        reasoning: "No valid corporate domain or contact records found after social filter",
        candidatesEvaluated: item.candidates.length,
        fromLiveSerper: item.fromLiveSerper,
      };
    });

    const verifiedCount = finalResults.filter((r) => r.status === "VERIFIED").length;
    const partialCount = finalResults.filter((r) => r.status === "PARTIAL").length;
    const naCount = finalResults.filter((r) => r.status === "NA").length;
    const enrichedLeadsCount = finalResults.filter(
      (r) => r.phone !== "N/A" || r.email !== "N/A"
    ).length;
    const titleMatchCount = finalResults.filter((r) => r.matchType === "TITLE_MATCH").length;
    const billedCredits = finalResults.reduce((acc, r) => acc + (r.creditsUsed || 0), 0);
    const zeroCostSearches = finalResults.filter((r) => r.creditsUsed === 0).length;

    return NextResponse.json({
      results: finalResults,
      meta: {
        totalProcessed: finalResults.length,
        verifiedCount,
        partialCount,
        naCount,
        enrichedLeadsCount,
        titleMatchCount,
        billedCredits,
        zeroCostSearches,
        usedLiveSerper: searchDataPerCompany.some((s) => s.fromLiveSerper),
      },
    });
  } catch (error: any) {
    console.error("Error in domain-extract route:", error);
    return NextResponse.json(
      { error: error?.message || "Internal server error during deep domain extraction & title matching" },
      { status: 500 }
    );
  }
}
