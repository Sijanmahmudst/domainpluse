import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const apiKey = body.apiKey || body.serperApiKey;

    if (!apiKey || typeof apiKey !== "string" || apiKey.trim().length === 0) {
      return NextResponse.json(
        { valid: false, message: "Please provide a valid API Key." },
        { status: 400 }
      );
    }

    const testRes = await fetch("https://google.serper.dev/search", {
      method: "POST",
      headers: {
        "X-API-KEY": apiKey.trim(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        q: "Google official site",
        num: 1,
      }),
    });

    if (testRes.status === 401 || testRes.status === 403) {
      return NextResponse.json(
        { valid: false, message: "Invalid Serper API Key (Unauthorized)." },
        { status: 401 }
      );
    }

    if (!testRes.ok) {
      const err = await testRes.text();
      return NextResponse.json(
        { valid: false, message: `Serper error ${testRes.status}: ${err}` },
        { status: testRes.status }
      );
    }

    const data = await testRes.json();
    const credits = data.credits ?? undefined;

    return NextResponse.json({
      valid: true,
      message: "Serper API connection successful!",
      credits,
    });
  } catch (err: any) {
    return NextResponse.json(
      { valid: false, message: err?.message || "Failed to reach Serper API" },
      { status: 500 }
    );
  }
}
