import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'DomainPulse AI - Bulk Company Domain Extractor & Validator',
  description: 'High-volume company domain extractor and intelligent validator powered by Serper Google Search API and Gemini AI.',
  openGraph: {
    title: 'DomainPulse AI - Bulk Company Domain Extractor & Validator',
    description: 'High-volume company domain extractor and intelligent validator powered by Serper Google Search API and Gemini AI.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DomainPulse AI - Bulk Company Domain Extractor & Validator',
    description: 'High-volume company domain extractor and intelligent validator powered by Serper Google Search API and Gemini AI.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased selection:bg-purple-500/20 selection:text-purple-300 font-['Plus_Jakarta_Sans',sans-serif]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
