"use client";

import React, { useState, useEffect, useRef } from "react";
import { Navbar, NavTab } from "@/components/Navbar";
import { StatsStrip } from "@/components/StatsStrip";
import { BulkProcessorTab } from "@/components/BulkProcessorTab";
import { ResultsTableTab } from "@/components/ResultsTableTab";
import { SinglePlaygroundTab } from "@/components/SinglePlaygroundTab";
import { SettingsTab } from "@/components/SettingsTab";
import { SavedListsSidebar } from "@/components/SavedListsSidebar";
import { ReasoningModal } from "@/components/ReasoningModal";
import { DEFAULT_SHIELD_DOMAINS } from "@/lib/shield-domains";
import { PRESET_SAMPLES } from "@/lib/presets";
import { ExtractedCompanyResult } from "@/app/api/domain-extract/route";
import { generateStandaloneHTML } from "@/lib/standalone-html-generator";
import {
  UniversalApiConfig,
  DEFAULT_UNIVERSAL_API_CONFIG,
  SUPPORTED_API_PROVIDERS,
} from "@/lib/api-providers";
import {
  CompanyListSession,
  createNewSession,
  loadSavedSessions,
  saveSessionsToStorage,
  calculateSessionStats,
  getActiveSessionId,
  setActiveSessionIdInStorage,
} from "@/lib/sessions";

export default function Home() {
  // Navigation
  const [activeTab, setActiveTab] = useState<NavTab>("extractor");

  // Multi-List Sessions State
  const [sessions, setSessions] = useState<CompanyListSession[]>(() => {
    if (typeof window !== "undefined") {
      return loadSavedSessions();
    }
    return [
      createNewSession(
        "List #1 - Semantic Titles Benchmark",
        PRESET_SAMPLES[0].companies.join("\n")
      ),
    ];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    if (typeof window !== "undefined") {
      const storedActive = getActiveSessionId();
      if (storedActive) return storedActive;
      const initialSessions = loadSavedSessions();
      if (initialSessions.length > 0) return initialSessions[0].id;
    }
    return "session_default";
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Active Session helper
  const activeSession =
    sessions.find((s) => s.id === activeSessionId) || sessions[0] || null;

  // Active inputs & results (bound to active session)
  const [inputText, setInputText] = useState(() => {
    return activeSession ? activeSession.inputText : PRESET_SAMPLES[0].companies.join("\n");
  });
  const [results, setResults] = useState<ExtractedCompanyResult[]>(() => {
    return activeSession ? activeSession.results : [];
  });
  const [selectedReasoningResult, setSelectedReasoningResult] =
    useState<ExtractedCompanyResult | null>(null);

  // Universal API Provider Config (persisted in localStorage)
  const [apiConfig, setApiConfig] = useState<UniversalApiConfig>(() => {
    if (typeof window !== "undefined") {
      const savedConfig = localStorage.getItem("domainpulse_universal_api_config");
      if (savedConfig) {
        try {
          return { ...DEFAULT_UNIVERSAL_API_CONFIG, ...JSON.parse(savedConfig) };
        } catch {
          // ignore
        }
      }
      // Migrate legacy serper key if exists
      const legacySerper = localStorage.getItem("domainpulse_serper_key");
      if (legacySerper) {
        return { ...DEFAULT_UNIVERSAL_API_CONFIG, apiKey: legacySerper };
      }
    }
    return DEFAULT_UNIVERSAL_API_CONFIG;
  });

  const [customGeminiApiKey, setCustomGeminiApiKey] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("domainpulse_gemini_key") || "";
    }
    return "";
  });

  const [strictness, setStrictness] = useState<number>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("domainpulse_strictness");
      return saved ? Number(saved) || 70 : 70;
    }
    return 70;
  });

  const [shieldDomains, setShieldDomains] = useState<string[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("domainpulse_shield_domains");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch {
          // ignore
        }
      }
    }
    return DEFAULT_SHIELD_DOMAINS;
  });

  // Data Enrichment Toggle
  const [enableEnrichment, setEnableEnrichment] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("domainpulse_enable_enrichment") !== "false";
    }
    return true;
  });

  // Batch Execution Tuning
  const [chunkSize, setChunkSize] = useState(10);
  const [concurrency, setConcurrency] = useState(2);
  const [delayMs, setDelayMs] = useState(250);

  // Batch State & Workers
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const isPausedRef = useRef(false);
  const isStopRequestedRef = useRef(false);

  // Performance & Stats
  const [processedCount, setProcessedCount] = useState(0);
  const [totalQueueCount, setTotalQueueCount] = useState(0);
  const [speedPerSec, setSpeedPerSec] = useState(0);
  const [etaSeconds, setEtaSeconds] = useState<number | null>(null);
  const [startTime, setStartTime] = useState(0);

  // Theme State
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("domainpulse_theme") as "dark" | "light";
      return saved || "dark";
    }
    return "dark";
  });

  // Sync theme class to documentElement
  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  // Sync current active session ID to localStorage
  useEffect(() => {
    if (activeSessionId) {
      setActiveSessionIdInStorage(activeSessionId);
    }
  }, [activeSessionId]);

  // When active session changes, update input text and results
  const handleSelectSession = (targetSessionId: string) => {
    if (targetSessionId === activeSessionId) return;

    // First save current working state into current session
    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            inputText,
            results,
            updatedAt: Date.now(),
            stats: calculateSessionStats(inputText, results),
          };
        }
        return s;
      });
      saveSessionsToStorage(updated);
      return updated;
    });

    // Now switch to target
    const target = sessions.find((s) => s.id === targetSessionId);
    if (target) {
      setActiveSessionId(target.id);
      setInputText(target.inputText);
      setResults(target.results);
      setProcessedCount(target.results.length);
      setTotalQueueCount(
        target.results.length > 0
          ? target.results.length
          : target.inputText.split("\n").filter((l) => l.trim().length > 0).length
      );
    }
  };

  // Create a new batch list
  const handleCreateNewSession = () => {
    // Save current session first
    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            inputText,
            results,
            updatedAt: Date.now(),
            stats: calculateSessionStats(inputText, results),
          };
        }
        return s;
      });

      const nextNum = updated.length + 1;
      const newSession = createNewSession(`List #${nextNum} - New Batch`, "");
      const finalSessions = [newSession, ...updated];
      saveSessionsToStorage(finalSessions);

      // Set active
      setActiveSessionId(newSession.id);
      setInputText(newSession.inputText);
      setResults(newSession.results);
      setProcessedCount(0);
      setTotalQueueCount(0);
      setActiveTab("extractor");

      return finalSessions;
    });
  };

  // Rename a session
  const handleRenameSession = (id: string, newName: string) => {
    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) =>
        s.id === id ? { ...s, name: newName, updatedAt: Date.now() } : s
      );
      saveSessionsToStorage(updated);
      return updated;
    });
  };

  // Delete a session
  const handleDeleteSession = (id: string) => {
    setSessions((prevSessions) => {
      const filtered = prevSessions.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const fallback = createNewSession("List #1 - Fresh Batch", "");
        filtered.push(fallback);
      }
      saveSessionsToStorage(filtered);

      // If active session was deleted, switch to the first remaining
      if (id === activeSessionId) {
        const nextActive = filtered[0];
        setActiveSessionId(nextActive.id);
        setInputText(nextActive.inputText);
        setResults(nextActive.results);
      }
      return filtered;
    });
  };

  // Duplicate a session
  const handleDuplicateSession = (id: string) => {
    const target = sessions.find((s) => s.id === id);
    if (!target) return;

    const clone: CompanyListSession = {
      ...target,
      id: `session_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: `${target.name} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      results: [...target.results],
    };

    setSessions((prev) => {
      const updated = [clone, ...prev];
      saveSessionsToStorage(updated);
      return updated;
    });
  };

  // Update Universal API Config
  const handleUpdateApiConfig = (newConfig: UniversalApiConfig) => {
    setApiConfig(newConfig);
    if (typeof window !== "undefined") {
      localStorage.setItem("domainpulse_universal_api_config", JSON.stringify(newConfig));
      // Sync legacy serper key
      if (newConfig.provider === "serper" && newConfig.apiKey) {
        localStorage.setItem("domainpulse_serper_key", newConfig.apiKey);
      }
    }
  };

  const handleUpdateCustomGeminiKey = (k: string) => {
    setCustomGeminiApiKey(k);
    if (typeof window !== "undefined") {
      localStorage.setItem("domainpulse_gemini_key", k);
    }
  };

  const handleUpdateStrictness = (val: number) => {
    setStrictness(val);
    if (typeof window !== "undefined") {
      localStorage.setItem("domainpulse_strictness", String(val));
    }
  };

  const handleUpdateShieldDomains = (domains: string[]) => {
    setShieldDomains(domains);
    if (typeof window !== "undefined") {
      localStorage.setItem("domainpulse_shield_domains", JSON.stringify(domains));
    }
  };

  const handleToggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    if (typeof window !== "undefined") {
      localStorage.setItem("domainpulse_theme", next);
    }
  };

  const handleToggleEnrichment = (val: boolean) => {
    setEnableEnrichment(val);
    if (typeof window !== "undefined") {
      localStorage.setItem("domainpulse_enable_enrichment", String(val));
    }
  };

  // Standalone HTML Download Trigger
  const handleDownloadStandalone = () => {
    const html = generateStandaloneHTML();
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `domainpulse_standalone_${new Date().toISOString().slice(0, 10)}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Helper to wait while paused
  const waitWhilePaused = async () => {
    while (isPausedRef.current && !isStopRequestedRef.current) {
      await new Promise((r) => setTimeout(r, 200));
    }
  };

  // Main Batch Processing Runner
  const handleStartProcessing = async () => {
    const companies = inputText
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    if (companies.length === 0) return;

    // Reset processing trackers
    setIsProcessing(true);
    setIsPaused(false);
    isPausedRef.current = false;
    isStopRequestedRef.current = false;

    setTotalQueueCount(companies.length);
    setProcessedCount(0);
    setSpeedPerSec(0);
    setEtaSeconds(null);
    const startTimestamp = Date.now();
    setStartTime(startTimestamp);

    // Group companies into chunks
    const chunks: string[][] = [];
    for (let i = 0; i < companies.length; i += chunkSize) {
      chunks.push(companies.slice(i, i + chunkSize));
    }

    let completedEntities = 0;
    const allExtracted: ExtractedCompanyResult[] = [];

    // Worker pool execution
    let currentChunkIndex = 0;

    const runWorker = async () => {
      while (currentChunkIndex < chunks.length && !isStopRequestedRef.current) {
        await waitWhilePaused();
        if (isStopRequestedRef.current) break;

        const chunkIdx = currentChunkIndex++;
        const currentBatch = chunks[chunkIdx];
        if (!currentBatch || currentBatch.length === 0) continue;

        try {
          const res = await fetch("/api/domain-extract", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              companies: currentBatch,
              apiConfig,
              customGeminiApiKey: customGeminiApiKey.trim() || undefined,
              strictness,
              customShieldDomains: shieldDomains,
              enableEnrichment,
            }),
          });

          if (!res.ok) {
            console.error(`Batch request failed: HTTP ${res.status}`);
            for (const c of currentBatch) {
              allExtracted.push({
                company: c,
                extractedDomain: "N/A",
                creditsUsed: 0,
                matchType: "NA",
                industry: "N/A",
                phone: "N/A",
                email: "N/A",
                status: "NA",
                confidence: 0,
                reasoning: "API error during batch extraction",
                candidatesEvaluated: 0,
                fromLiveSerper: false,
              });
            }
          } else {
            const data = await res.json();
            if (data.results && Array.isArray(data.results)) {
              allExtracted.push(...data.results);
            }
          }
        } catch (err) {
          console.error("Worker error:", err);
          for (const c of currentBatch) {
            allExtracted.push({
              company: c,
              extractedDomain: "N/A",
              creditsUsed: 0,
              matchType: "NA",
              industry: "N/A",
              phone: "N/A",
              email: "N/A",
              status: "NA",
              confidence: 0,
              reasoning: "Network error during batch extraction",
              candidatesEvaluated: 0,
              fromLiveSerper: false,
            });
          }
        }

        completedEntities += currentBatch.length;
        setProcessedCount(completedEntities);
        const updatedResults = [...allExtracted];
        setResults(updatedResults);

        // Update active session in background
        setSessions((prevSessions) => {
          const updated = prevSessions.map((s) => {
            if (s.id === activeSessionId) {
              return {
                ...s,
                results: updatedResults,
                updatedAt: Date.now(),
                status: "processing" as const,
                stats: calculateSessionStats(inputText, updatedResults),
              };
            }
            return s;
          });
          saveSessionsToStorage(updated);
          return updated;
        });

        // Calculate velocity & ETA
        const elapsedSec = (Date.now() - startTimestamp) / 1000;
        if (elapsedSec > 0.5) {
          const currentSpeed = completedEntities / elapsedSec;
          setSpeedPerSec(currentSpeed);
          const remaining = companies.length - completedEntities;
          const eta = currentSpeed > 0 ? Math.ceil(remaining / currentSpeed) : 0;
          setEtaSeconds(eta);
        }

        if (delayMs > 0) {
          await new Promise((r) => setTimeout(r, delayMs));
        }
      }
    };

    const workers = Array.from({ length: Math.min(concurrency, chunks.length) }, () =>
      runWorker()
    );
    await Promise.all(workers);

    setIsProcessing(false);
    setIsPaused(false);
    isPausedRef.current = false;
    isStopRequestedRef.current = false;

    // Mark active session as completed
    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            results: allExtracted,
            updatedAt: Date.now(),
            status: "completed" as const,
            stats: calculateSessionStats(inputText, allExtracted),
          };
        }
        return s;
      });
      saveSessionsToStorage(updated);
      return updated;
    });
  };

  const handlePause = () => {
    setIsPaused(true);
    isPausedRef.current = true;
  };

  const handleResume = () => {
    setIsPaused(false);
    isPausedRef.current = false;
  };

  const handleStop = () => {
    isStopRequestedRef.current = true;
    setIsProcessing(false);
    setIsPaused(false);
    isPausedRef.current = false;
  };

  const handleClearAll = () => {
    handleStop();
    setInputText("");
    setResults([]);
    setProcessedCount(0);
    setTotalQueueCount(0);
    setSpeedPerSec(0);
    setEtaSeconds(null);
  };

  const handleClearResultsOnly = () => {
    setResults([]);
  };

  // Metrics
  const verifiedCount = results.filter((r) => r.status === "VERIFIED").length;
  const naCount = results.filter((r) => r.status === "NA").length;
  const enrichedCount = results.filter(
    (r) => (r.phone && r.phone !== "N/A") || (r.email && r.email !== "N/A")
  ).length;
  const billedCredits = results.reduce(
    (acc, r) => acc + (r.creditsUsed !== undefined ? r.creditsUsed : r.extractedDomain && r.extractedDomain !== "N/A" ? 1 : 0),
    0
  );
  const zeroCostSearches = results.filter(
    (r) => r.creditsUsed === 0 || (!r.extractedDomain || r.extractedDomain === "N/A")
  ).length;

  const progressPct =
    totalQueueCount > 0 ? Math.round((processedCount / totalQueueCount) * 100) : 0;

  const providerMeta = SUPPORTED_API_PROVIDERS[apiConfig.provider] || SUPPORTED_API_PROVIDERS.serper;
  const isProviderConfigured = apiConfig.apiKey && apiConfig.apiKey.trim().length > 0;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-purple-500/20 selection:text-purple-400">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        resultsCount={results.length}
        verifiedCount={verifiedCount}
        hasSerperKey={Boolean(isProviderConfigured)}
        isProcessing={isProcessing}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onDownloadStandalone={handleDownloadStandalone}
        activeSessionName={activeSession?.name}
        sessionCount={sessions.length}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        providerName={providerMeta.name}
      />

      {/* Multi-List Saved Sessions Sidebar */}
      <SavedListsSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        onCreateNewSession={handleCreateNewSession}
        onRenameSession={handleRenameSession}
        onDeleteSession={handleDeleteSession}
        onDuplicateSession={handleDuplicateSession}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Real-time KPI Stats Strip */}
        <StatsStrip
          totalInQueue={
            isProcessing || results.length > 0
              ? totalQueueCount
              : inputText.split("\n").filter((l) => l.trim().length > 0).length
          }
          processedCount={processedCount}
          verifiedCount={verifiedCount}
          enrichedCount={enrichedCount}
          naCount={naCount}
          speedPerSec={speedPerSec}
          etaSeconds={etaSeconds}
          isProcessing={isProcessing}
          billedCredits={billedCredits}
          zeroCostSearches={zeroCostSearches}
        />

        {/* Tab 1: Bulk Extractor Queue */}
        {activeTab === "extractor" && (
          <BulkProcessorTab
            inputText={inputText}
            onInputChange={(val) => {
              setInputText(val);
              // Auto-update active session input text
              setSessions((prev) =>
                prev.map((s) => (s.id === activeSessionId ? { ...s, inputText: val } : s))
              );
            }}
            isProcessing={isProcessing}
            isPaused={isPaused}
            progressPct={progressPct}
            processedCount={processedCount}
            totalCount={totalQueueCount}
            onStart={handleStartProcessing}
            onPause={handlePause}
            onResume={handleResume}
            onStop={handleStop}
            onClear={handleClearAll}
            chunkSize={chunkSize}
            onChangeChunkSize={setChunkSize}
            concurrency={concurrency}
            onChangeConcurrency={setConcurrency}
            delayMs={delayMs}
            onChangeDelayMs={setDelayMs}
            hasSerperKey={Boolean(isProviderConfigured)}
            onGoToResults={() => setActiveTab("results")}
            enableEnrichment={enableEnrichment}
            onToggleEnrichment={handleToggleEnrichment}
          />
        )}

        {/* Tab 2: Live Results Table with Dual Export (CSV & Excel) */}
        {activeTab === "results" && (
          <ResultsTableTab
            results={results}
            onClearResults={handleClearResultsOnly}
            onOpenReasoning={(item) => setSelectedReasoningResult(item)}
          />
        )}

        {/* Tab 3: Single Inspection Playground */}
        {activeTab === "playground" && (
          <SinglePlaygroundTab
            apiConfig={apiConfig}
            serperApiKey={apiConfig.apiKey}
            customGeminiApiKey={customGeminiApiKey}
            strictness={strictness}
          />
        )}

        {/* Tab 4: Universal API Gateway & Shield Configuration */}
        {activeTab === "settings" && (
          <SettingsTab
            apiConfig={apiConfig}
            onUpdateApiConfig={handleUpdateApiConfig}
            customGeminiApiKey={customGeminiApiKey}
            onUpdateCustomGeminiKey={handleUpdateCustomGeminiKey}
            strictness={strictness}
            onUpdateStrictness={handleUpdateStrictness}
            shieldDomains={shieldDomains}
            onUpdateShieldDomains={handleUpdateShieldDomains}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800/80 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              DomainPulse AI
            </span>
            <span>·</span>
            <span>Universal Multi-API Batch Domain & Contact Enrichment</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Provider: {providerMeta.name}</span>
            <span>·</span>
            <span>Gemini 3.8 Flash</span>
            <span>·</span>
            <span>Dual CSV & Excel Export</span>
            <span>·</span>
            <button
              onClick={handleDownloadStandalone}
              className="text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              Standalone HTML
            </button>
          </div>
        </div>
      </footer>

      {/* Gemini AI Reasoning Modal */}
      {selectedReasoningResult && (
        <ReasoningModal
          result={selectedReasoningResult}
          onClose={() => setSelectedReasoningResult(null)}
        />
      )}
    </div>
  );
}
