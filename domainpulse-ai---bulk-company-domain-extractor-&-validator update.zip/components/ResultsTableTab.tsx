"use client";

import React, { useState, useMemo } from "react";
import {
  Search,
  Filter,
  Copy,
  Check,
  ExternalLink,
  Download,
  FileSpreadsheet,
  FileText,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Globe2,
  Phone,
  Mail,
  Briefcase,
  Sparkles,
  Award,
  Layers,
} from "lucide-react";
import { ExtractedCompanyResult } from "@/app/api/domain-extract/route";
import { exportToCSV, exportToExcel } from "@/lib/export-utils";

interface ResultsTableTabProps {
  results: ExtractedCompanyResult[];
  onClearResults: () => void;
  onOpenReasoning: (result: ExtractedCompanyResult) => void;
}

export function ResultsTableTab({
  results,
  onClearResults,
  onOpenReasoning,
}: ResultsTableTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterMode, setFilterMode] = useState<
    "ALL" | "EXACT_MATCH" | "TITLE_MATCH" | "ENRICHED" | "NA"
  >("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [copiedCell, setCopiedCell] = useState<string | null>(null);
  const [bulkCopied, setBulkCopied] = useState(false);

  // Filtered dataset
  const filteredResults = useMemo(() => {
    return results.filter((item) => {
      // Filter mode
      if (filterMode === "EXACT_MATCH" && item.matchType !== "EXACT_MATCH") return false;
      if (filterMode === "TITLE_MATCH" && item.matchType !== "TITLE_MATCH") return false;
      if (filterMode === "NA" && item.status !== "NA") return false;
      if (filterMode === "ENRICHED" && item.phone === "N/A" && item.email === "N/A") return false;

      // Text search across Company, Domain, Industry, Phone, Email, Title
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const compMatch = item.company.toLowerCase().includes(q);
        const domMatch = item.extractedDomain.toLowerCase().includes(q);
        const indMatch = item.industry?.toLowerCase().includes(q);
        const phoneMatch = item.phone?.toLowerCase().includes(q);
        const emailMatch = item.email?.toLowerCase().includes(q);
        const titleMatch = item.matchedTitle?.toLowerCase().includes(q);
        const reasonMatch = item.reasoning?.toLowerCase().includes(q);
        return compMatch || domMatch || indMatch || phoneMatch || emailMatch || titleMatch || reasonMatch;
      }

      return true;
    });
  }, [results, filterMode, searchQuery]);

  // Pagination calculations
  const totalPages = Math.max(1, Math.ceil(filteredResults.length / pageSize));
  const activePage = Math.min(currentPage, totalPages);
  const startIndex = (activePage - 1) * pageSize;
  const paginatedRows = filteredResults.slice(startIndex, startIndex + pageSize);

  const handleCopy = (text: string, id: string) => {
    if (!text || text === "N/A") return;
    navigator.clipboard.writeText(text);
    setCopiedCell(id);
    setTimeout(() => setCopiedCell(null), 2000);
  };

  const handleCopyAllDomains = () => {
    const domains = results
      .filter((r) => r.extractedDomain && r.extractedDomain !== "N/A")
      .map((r) => r.extractedDomain);

    if (domains.length === 0) return;
    navigator.clipboard.writeText(domains.join("\n"));
    setBulkCopied(true);
    setTimeout(() => setBulkCopied(false), 2500);
  };

  const exportCSV = () => {
    exportToCSV(results, "domainpulse_deep_matches");
  };

  const exportExcel = () => {
    exportToExcel(results, "domainpulse_deep_matches");
  };

  const titleMatchCount = results.filter((r) => r.matchType === "TITLE_MATCH").length;
  const exactMatchCount = results.filter((r) => r.matchType === "EXACT_MATCH").length;

  return (
    <div className="space-y-4">
      <div className="border border-slate-200 dark:border-slate-800 rounded-3xl bg-white dark:bg-slate-900/40 p-5 sm:p-6 space-y-4 shadow-sm backdrop-blur">
        {/* Table Toolbar */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          {/* Search & Dynamic Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 flex-1 max-w-2xl">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search by company, domain, industry, phone, or title..."
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2.5 top-2.5 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Segmented Filter Pills */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs shrink-0 flex-wrap">
              <button
                onClick={() => {
                  setFilterMode("ALL");
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  filterMode === "ALL"
                    ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                All ({results.length})
              </button>

              <button
                onClick={() => {
                  setFilterMode("TITLE_MATCH");
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
                  filterMode === "TITLE_MATCH"
                    ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-xs"
                    : "text-purple-600 dark:text-purple-400 hover:text-purple-800"
                }`}
                title="Domains discovered through Page Title & Snippet semantic matching"
              >
                <Sparkles className="w-3 h-3 text-purple-500" />
                <span>Title Matches ({titleMatchCount})</span>
              </button>

              <button
                onClick={() => {
                  setFilterMode("EXACT_MATCH");
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  filterMode === "EXACT_MATCH"
                    ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Exact ({exactMatchCount})
              </button>

              <button
                onClick={() => {
                  setFilterMode("ENRICHED");
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  filterMode === "ENRICHED"
                    ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Leads
              </button>

              <button
                onClick={() => {
                  setFilterMode("NA");
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  filterMode === "NA"
                    ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                N/A
              </button>
            </div>
          </div>

          {/* Action Buttons: Copy Verified, Export CSV, Export XLSX */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleCopyAllDomains}
              disabled={results.length === 0}
              className="px-3 py-1.5 text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 border border-indigo-200 dark:border-indigo-800 rounded-xl transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              {bulkCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{bulkCopied ? "Copied!" : "Copy Domains"}</span>
            </button>

            <button
              onClick={exportCSV}
              disabled={results.length === 0}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={exportExcel}
              disabled={results.length === 0}
              className="px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200 dark:border-emerald-800 rounded-xl transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Excel (.xlsx)</span>
            </button>

            {results.length > 0 && (
              <button
                onClick={onClearResults}
                className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                title="Clear results table"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Dynamic Enriched Table */}
        <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-2xl bg-slate-50/50 dark:bg-slate-950/60">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100/90 dark:bg-slate-900/90 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-3 w-10 font-mono text-center">#</th>
                <th className="py-3 px-3.5 min-w-[160px]">Company Name</th>
                <th className="py-3 px-3.5 min-w-[180px]">Extracted Domain</th>
                <th className="py-3 px-2 w-20 text-center">Credit</th>
                <th className="py-3 px-3 min-w-[140px]">Industry</th>
                <th className="py-3 px-3 min-w-[130px]">Phone Number</th>
                <th className="py-3 px-3 min-w-[150px]">Business Email</th>
                <th className="py-3 px-2.5 w-28 text-center">Match Method</th>
                <th className="py-3 px-2.5 w-16 text-center">Score</th>
                <th className="py-3 px-3 text-right w-20">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/80 dark:divide-slate-800/60 text-slate-700 dark:text-slate-300 font-normal">
              {paginatedRows.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-14 text-center">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <Globe2 className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                      <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
                        {results.length === 0
                          ? "No company records scanned yet."
                          : "No records match the current filter or search."}
                      </p>
                      <p className="text-xs text-slate-400 dark:text-slate-500">
                        {results.length === 0
                          ? "Paste company names in the Bulk Extractor tab to start."
                          : "Try resetting your search query or filter selection."}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedRows.map((item, idx) => {
                  const globalIdx = startIndex + idx + 1;
                  const domain = item.extractedDomain;
                  const hasDomain = domain && domain !== "N/A";
                  const hasPhone = item.phone && item.phone !== "N/A";
                  const hasEmail = item.email && item.email !== "N/A";
                  const hasIndustry = item.industry && item.industry !== "N/A";

                  return (
                    <tr
                      key={`${item.company}-${globalIdx}`}
                      className="hover:bg-indigo-50/40 dark:hover:bg-slate-900/50 transition-colors group"
                    >
                      {/* 1. Index */}
                      <td className="py-3 px-3 text-center font-mono text-slate-400 tabular-nums">
                        {globalIdx}
                      </td>

                      {/* 2. Company Name */}
                      <td className="py-3 px-3.5 font-semibold text-slate-900 dark:text-white">
                        <div className="truncate max-w-[170px]" title={item.company}>
                          {item.company}
                        </div>
                      </td>

                      {/* 3. Domain + Rank Badge + Favicon */}
                      <td className="py-3 px-3.5">
                        {hasDomain ? (
                          <div className="flex items-center gap-1.5">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={`https://www.google.com/s2/favicons?domain=${domain}&sz=32`}
                              alt=""
                              className="w-3.5 h-3.5 rounded-xs shrink-0 object-contain bg-slate-100 dark:bg-slate-800"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = "none";
                              }}
                            />
                            <a
                              href={`https://${domain}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-mono text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 truncate max-w-[130px]"
                            >
                              <span>{domain}</span>
                              <ExternalLink className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                            </a>

                            {/* Rank Indicator Badge */}
                            {item.matchedRank !== undefined && (
                              <span
                                className={`text-[10px] font-mono px-1.5 py-0.2 rounded shrink-0 ${
                                  item.matchedRank === 0
                                    ? "bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300"
                                    : item.matchedRank === 1
                                    ? "bg-slate-100 dark:bg-slate-800 text-slate-500"
                                    : "bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300"
                                }`}
                                title={item.matchedRank === 0 ? "Google Knowledge Graph source" : `Discovered at Google Organic Rank #${item.matchedRank}`}
                              >
                                {item.matchedRank === 0 ? "KG" : `#${item.matchedRank}`}
                              </span>
                            )}

                            <button
                              onClick={() => handleCopy(domain, `dom-${globalIdx}`)}
                              className="text-slate-400 hover:text-indigo-600 p-0.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                              title="Copy domain"
                            >
                              {copiedCell === `dom-${globalIdx}` ? (
                                <Check className="w-3 h-3 text-emerald-500" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        ) : (
                          <span className="font-mono text-xs text-slate-400 dark:text-slate-600 italic">
                            N/A
                          </span>
                        )}
                      </td>

                      {/* 3b. Credit Billed (Conditional Zero-Cost Policy) */}
                      <td className="py-3 px-2 text-center whitespace-nowrap">
                        {item.creditsUsed === 0 || !hasDomain ? (
                          <span
                            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"
                            title="Zero-Cost row: No domain verified, so API credit billed is 0"
                          >
                            0 Free
                          </span>
                        ) : (
                          <span
                            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20"
                            title="1 API Credit billed for verified company extraction"
                          >
                            1 Credit
                          </span>
                        )}
                      </td>

                      {/* 4. Industry */}
                      <td className="py-3 px-3">
                        {hasIndustry ? (
                          <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200">
                            <Briefcase className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="truncate max-w-[130px]" title={item.industry}>
                              {item.industry}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 dark:text-slate-600 italic">N/A</span>
                        )}
                      </td>

                      {/* 5. Phone Number */}
                      <td className="py-3 px-3">
                        {hasPhone ? (
                          <div className="flex items-center gap-1.5 font-mono text-slate-800 dark:text-slate-200">
                            <Phone className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                            <span className="truncate max-w-[110px]" title={item.phone}>
                              {item.phone}
                            </span>
                            <button
                              onClick={() => handleCopy(item.phone, `phone-${globalIdx}`)}
                              className="text-slate-400 hover:text-purple-600 p-0.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                              title="Copy phone number"
                            >
                              {copiedCell === `phone-${globalIdx}` ? (
                                <Check className="w-3 h-3 text-emerald-500" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        ) : (
                          <span className="font-mono text-slate-400 dark:text-slate-600 italic">N/A</span>
                        )}
                      </td>

                      {/* 6. Business Email */}
                      <td className="py-3 px-3">
                        {hasEmail ? (
                          <div className="flex items-center gap-1.5 font-mono text-slate-800 dark:text-slate-200">
                            <Mail className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                            <a
                              href={`mailto:${item.email}`}
                              className="hover:underline text-indigo-600 dark:text-indigo-400 truncate max-w-[130px]"
                              title={item.email}
                            >
                              {item.email}
                            </a>
                            <button
                              onClick={() => handleCopy(item.email, `email-${globalIdx}`)}
                              className="text-slate-400 hover:text-indigo-600 p-0.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                              title="Copy email"
                            >
                              {copiedCell === `email-${globalIdx}` ? (
                                <Check className="w-3 h-3 text-emerald-500" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        ) : (
                          <span className="font-mono text-slate-400 dark:text-slate-600 italic">N/A</span>
                        )}
                      </td>

                      {/* 7. Match Method Badge */}
                      <td className="py-3 px-2.5 text-center">
                        {item.matchType === "TITLE_MATCH" ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-50 dark:bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-500/20 shadow-xs" title="Domain verified via semantic page title & snippet analysis">
                            <Sparkles className="w-2.5 h-2.5" />
                            <span>TITLE MATCH</span>
                          </span>
                        ) : item.matchType === "EXACT_MATCH" ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20">
                            EXACT MATCH
                          </span>
                        ) : item.matchType === "ENRICHED_ONLY" ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-500/20">
                            LEADS ONLY
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700/60">
                            N/A
                          </span>
                        )}
                      </td>

                      {/* 8. Confidence Score */}
                      <td className="py-3 px-2.5 text-center">
                        <span className="font-mono font-bold text-xs tabular-nums text-slate-700 dark:text-slate-200">
                          {item.confidence}%
                        </span>
                      </td>

                      {/* 9. Inspect AI Reasoning */}
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => onOpenReasoning(item)}
                          className="px-2 py-1 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-300 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1"
                          title="Inspect deep search & title matching logic"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                          <span className="text-[11px]">Inspect</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Pagination & Metrics Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-500 dark:text-slate-400">
          <div>
            Showing{" "}
            <span className="font-mono font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
              {filteredResults.length === 0 ? 0 : startIndex + 1}
            </span>{" "}
            to{" "}
            <span className="font-mono font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
              {Math.min(startIndex + pageSize, filteredResults.length)}
            </span>{" "}
            of{" "}
            <span className="font-mono font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
              {filteredResults.length}
            </span>{" "}
            records
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span>Per page:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-2 py-1 text-slate-900 dark:text-slate-200"
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={activePage <= 1}
                className="p-1 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <span className="font-mono tabular-nums px-2">
                {activePage} / {totalPages}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={activePage >= totalPages}
                className="p-1 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
