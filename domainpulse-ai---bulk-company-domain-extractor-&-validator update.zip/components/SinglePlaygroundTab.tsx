"use client";

import React, { useState } from "react";
import {
  Search,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  Globe,
  ExternalLink,
  Copy,
  Check,
  Loader2,
  CheckCircle2,
  XCircle,
  HelpCircle,
} from "lucide-react";
import { cleanCompanyNameForSearch } from "@/lib/shield-domains";
import { ExtractedCompanyResult } from "@/app/api/domain-extract/route";
import { UniversalApiConfig } from "@/lib/api-providers";

interface SinglePlaygroundTabProps {
  serperApiKey?: string;
  apiConfig?: UniversalApiConfig;
  customGeminiApiKey: string;
  strictness: number;
}

export function SinglePlaygroundTab({
  serperApiKey = "",
  apiConfig,
  customGeminiApiKey,
  strictness,
}: SinglePlaygroundTabProps) {
  const [testCompany, setTestCompany] = useState("Alphabet Inc.");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ExtractedCompanyResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const sampleQuickTests = [
    "Alphabet Inc.",
    "Meta Platforms, Inc.",
    "Caterpillar Inc.",
    "Spotify Technology S.A.",
    "Shopee Pte. Ltd.",
    "BMW Bayerische Motoren Werke AG",
    "Kraft Heinz Company",
    "FakeGhostEnterpriseNonExistent999",
  ];

  const handleTest = async (overrideName?: string) => {
    const nameToTest = overrideName || testCompany;
    if (!nameToTest.trim()) return;

    setIsLoading(true);
    setErrorMsg(null);
    setResult(null);

    try {
      const res = await fetch("/api/domain-extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companies: [nameToTest.trim()],
          apiConfig,
          serperApiKey: serperApiKey.trim() || undefined,
          customGeminiApiKey: customGeminiApiKey.trim() || undefined,
          strictness,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      if (data.results && data.results.length > 0) {
        setResult(data.results[0]);
      } else {
        throw new Error("No evaluation returned");
      }
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to inspect company domain");
    } finally {
      setIsLoading(false);
    }
  };

  const { normalized, detectedSuffix } = cleanCompanyNameForSearch(
    result ? result.company : testCompany
  );

  return (
    <div className="space-y-6">
      <div className="border border-slate-200 dark:border-slate-800 rounded-3xl bg-white dark:bg-slate-900/40 p-5 sm:p-7 space-y-6 shadow-sm backdrop-blur">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Search className="w-5 h-5 text-indigo-500" />
            <span>Deep Search & Semantic Title Matching Playground</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Test any corporate entity to see legal suffix normalization, multi-result Serper scanning (top 10 results), semantic title and snippet matching via Gemini AI, and fallback contact lead enrichment.
          </p>
        </div>

        {/* Input Bar */}
        <div className="flex flex-col sm:flex-row gap-2 max-w-2xl">
          <div className="relative flex-1">
            <input
              type="text"
              value={testCompany}
              onChange={(e) => setTestCompany(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleTest()}
              placeholder="e.g. Alphabet Inc., Meta Platforms, Inc., Caterpillar Inc., Spotify Technology S.A."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>
          <button
            onClick={() => handleTest()}
            disabled={isLoading || !testCompany.trim()}
            className="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors flex items-center justify-center gap-2 disabled:opacity-50 shrink-0 cursor-pointer"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Scanning Top 10...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Deep Inspect</span>
              </>
            )}
          </button>
        </div>

        {/* Sample chips */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-400">Quick test cases:</span>
          {sampleQuickTests.map((c) => (
            <button
              key={c}
              onClick={() => {
                setTestCompany(c);
                handleTest(c);
              }}
              className="px-2.5 py-1 text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg transition-colors cursor-pointer"
            >
              {c}
            </button>
          ))}
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 text-rose-700 dark:text-rose-400 text-xs">
            {errorMsg}
          </div>
        )}

        {/* Results breakdown */}
        {result && (
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-5 animate-in fade-in duration-300">
            {/* Resolution Hero Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/60 via-purple-50/40 to-slate-50/50 dark:from-indigo-950/30 dark:via-purple-950/20 dark:to-slate-900/40 border border-indigo-100 dark:border-indigo-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {result.company}
                  </h3>
                  {detectedSuffix && (
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                      Suffix: {detectedSuffix}
                    </span>
                  )}
                  {result.matchType === "TITLE_MATCH" && (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 flex items-center gap-1 border border-purple-200 dark:border-purple-800">
                      <Sparkles className="w-3 h-3" />
                      Semantic Title Match
                    </span>
                  )}
                  {result.matchType === "EXACT_MATCH" && (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                      Exact Domain Match
                    </span>
                  )}
                  {result.matchedRank && (
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-cyan-100 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800">
                      Rank #{result.matchedRank}
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 flex items-center gap-2 flex-wrap">
                  <span>Normalized stem:</span>
                  <strong className="text-slate-700 dark:text-slate-300 font-mono">
                    {normalized}
                  </strong>
                  <span>·</span>
                  <span>Evaluated Candidates:</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">
                    {result.candidatesEvaluated} organic results
                  </span>
                </div>
                {result.matchedTitle && (
                  <div className="text-xs text-purple-700 dark:text-purple-300 mt-2 bg-purple-50 dark:bg-purple-950/40 p-2 rounded-lg border border-purple-100 dark:border-purple-900/40">
                    <span className="font-semibold text-slate-500 dark:text-slate-400">Matched Page Title: </span>
                    &ldquo;{result.matchedTitle}&rdquo;
                  </div>
                )}
              </div>

              {/* Status & Final Domain */}
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="flex items-center gap-1.5 justify-end flex-wrap">
                    {result.creditsUsed === 0 || result.extractedDomain === "N/A" ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                        0 Free (Zero-Cost)
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30">
                        1 Credit Billed
                      </span>
                    )}
                    {result.status === "VERIFIED" ? (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        VERIFIED ({result.confidence}%)
                      </span>
                    ) : result.status === "PARTIAL" ? (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                        PARTIAL ({result.confidence}%)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-slate-500/15 text-slate-600 dark:text-slate-400 border border-slate-500/30">
                        <XCircle className="w-3.5 h-3.5" />
                        N/A ({result.confidence}%)
                      </span>
                    )}
                  </div>
                  <div className="text-base font-mono font-bold text-indigo-600 dark:text-indigo-300 mt-1">
                    {result.extractedDomain}
                  </div>
                </div>

                {result.extractedDomain !== "N/A" && (
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(result.extractedDomain);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:text-indigo-600 transition-colors shadow-xs cursor-pointer"
                    title="Copy domain"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                )}
              </div>
            </div>

            {/* Enriched Lead Details Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Verified Industry
                </div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white mt-1">
                  {result.industry || "N/A"}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Company Phone Number
                </div>
                <div className="text-xs font-mono font-bold text-purple-600 dark:text-purple-400 mt-1">
                  {result.phone || "N/A"}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Verified Business Email
                </div>
                <div className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400 mt-1 truncate">
                  {result.email || "N/A"}
                </div>
              </div>
            </div>

            {/* Step-by-Step Decision Pipeline */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {/* Step 1: Query & Serper Execution */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 space-y-2">
                <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-indigo-500" />
                  <span>1. Serper Search Formulation</span>
                </div>
                <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 font-mono text-[11px] text-slate-700 dark:text-slate-300 break-all">
                  q = &quot;{normalized} official website&quot;
                </div>
                <div className="text-[11px] text-slate-500">
                  {result.fromLiveSerper
                    ? "Live Google search fetched via Serper.dev API"
                    : "Simulated realistic organic result candidate for demo"}
                </div>
              </div>

              {/* Step 2: 100+ Platform Shield Filter */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 space-y-2">
                <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>2. Social & Directory Shield</span>
                </div>
                <div className="text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
                  <div>100+ platforms filtered (LinkedIn, Wikipedia, Yelp, Crunchbase, etc.)</div>
                  <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Aggregators and social profiles discarded</span>
                  </div>
                </div>
              </div>

              {/* Step 3: Gemini AI Reasoning */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/60 space-y-2">
                <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                  <span>3. Gemini AI Fuzzy Match</span>
                </div>
                <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-[11px]">
                  &quot;{result.reasoning}&quot;
                </div>
                <div className="text-[11px] text-slate-500">
                  Model: <strong className="text-slate-700 dark:text-slate-300">gemini-3.8-flash</strong> · Confidence: <strong className="font-mono">{result.confidence}%</strong>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
