"use client";

import React, { useState, useRef } from "react";
import {
  UploadCloud,
  Play,
  Pause,
  Square,
  RotateCcw,
  Sparkles,
  FileSpreadsheet,
  Settings2,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
} from "lucide-react";
import { PRESET_SAMPLES, PresetSample } from "@/lib/presets";

interface BulkProcessorTabProps {
  inputText: string;
  onInputChange: (val: string) => void;
  isProcessing: boolean;
  isPaused: boolean;
  progressPct: number;
  processedCount: number;
  totalCount: number;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  onClear: () => void;
  chunkSize: number;
  onChangeChunkSize: (val: number) => void;
  concurrency: number;
  onChangeConcurrency: (val: number) => void;
  delayMs: number;
  onChangeDelayMs: (val: number) => void;
  hasSerperKey: boolean;
  onGoToResults: () => void;
  enableEnrichment: boolean;
  onToggleEnrichment: (val: boolean) => void;
}

export function BulkProcessorTab({
  inputText,
  onInputChange,
  isProcessing,
  isPaused,
  progressPct,
  processedCount,
  totalCount,
  onStart,
  onPause,
  onResume,
  onStop,
  onClear,
  chunkSize,
  onChangeChunkSize,
  concurrency,
  onChangeConcurrency,
  delayMs,
  onChangeDelayMs,
  hasSerperKey,
  onGoToResults,
  enableEnrichment,
  onToggleEnrichment,
}: BulkProcessorTabProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  // Compute number of non-empty lines
  const lines = inputText
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  const lineCount = lines.length;

  const handleFileUpload = (file: File) => {
    setUploadedFileName(file.name);
    const reader = new FileReader();

    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) return;

      // Check if CSV with commas
      const rawLines = content.split(/\r?\n/).filter((l) => l.trim().length > 0);
      if (rawLines.length === 0) return;

      // Simple CSV parsing: if first line contains commas, check if it's a header
      const firstLine = rawLines[0];
      if (firstLine.includes(",")) {
        const columns = firstLine.split(",").map((c) => c.replace(/['"“”]/g, "").trim());
        // Find column that looks like company/name/organization
        const colIdx = columns.findIndex((c) =>
          /company|organization|name|business|entity|firm/i.test(c)
        );

        if (colIdx >= 0 && rawLines.length > 1) {
          // Extract from that column, skipping header
          const extractedNames: string[] = [];
          for (let i = 1; i < rawLines.length; i++) {
            const rowCols = rawLines[i].split(",").map((c) => c.replace(/['"“”]/g, "").trim());
            if (rowCols[colIdx]) {
              extractedNames.push(rowCols[colIdx]);
            }
          }
          if (extractedNames.length > 0) {
            onInputChange(extractedNames.join("\n"));
            return;
          }
        }
      }

      // Default: clean lines
      onInputChange(rawLines.join("\n"));
    };

    reader.readAsText(file);
  };

  const handlePresetSelect = (preset: PresetSample) => {
    onInputChange(preset.companies.join("\n"));
  };

  return (
    <div className="space-y-6">
      <div className="border border-slate-200 dark:border-slate-800 rounded-3xl bg-white dark:bg-slate-900/40 p-5 sm:p-7 space-y-6 shadow-sm backdrop-blur">
        {/* Header & Quick Presets */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800/80">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Bulk Company Extractor Queue</span>
              <span className="text-xs font-mono font-normal px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                50,000+ items supported
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Paste names, drop a CSV, or choose an industry benchmark preset below.
            </p>
          </div>

          {/* Quick Presets Strip */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-500" />
              Presets:
            </span>
            {PRESET_SAMPLES.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handlePresetSelect(preset)}
                disabled={isProcessing}
                className="px-2.5 py-1 text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg transition-colors disabled:opacity-50"
                title={preset.description}
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        {/* Text Area with line count & status */}
        <div className="relative">
          <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700/80 tabular-nums">
              {lineCount} {lineCount === 1 ? "entity" : "entities"}
            </span>
          </div>
          <textarea
            value={inputText}
            onChange={(e) => onInputChange(e.target.value)}
            disabled={isProcessing}
            rows={10}
            placeholder={`Paste company names here (one per line)...

Example:
Apple Inc.
Spotify Technology S.A.
Shopee Pte. Ltd.
BMW Bayerische Motoren Werke AG
Stripe, Inc.
Grab Holdings Inc.
BioNTech SE
LVMH Moët Hennessy Louis Vuitton SE`}
            className="w-full bg-slate-50/70 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 text-sm font-mono text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-y leading-relaxed disabled:opacity-60"
          ></textarea>
        </div>

        {/* Drag & Drop Area */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              handleFileUpload(e.dataTransfer.files[0]);
            }
          }}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-all ${
            isDragging
              ? "border-indigo-500 bg-indigo-500/10"
              : "border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 bg-slate-50/40 dark:bg-slate-950/30"
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileUpload(e.target.files[0]);
              }
            }}
            accept=".csv,.txt"
            className="hidden"
          />
          <div className="flex items-center justify-center gap-2.5 text-xs text-slate-600 dark:text-slate-400">
            <UploadCloud className="w-5 h-5 text-indigo-500" />
            <span>
              {uploadedFileName ? (
                <>
                  Uploaded:{" "}
                  <strong className="text-indigo-600 dark:text-indigo-400">
                    {uploadedFileName}
                  </strong>{" "}
                  ({lineCount} companies parsed)
                </>
              ) : (
                <>
                  Drag & drop a <strong className="text-slate-800 dark:text-slate-200">CSV or TXT</strong> file here, or click to browse.
                </>
              )}
            </span>
          </div>
        </div>

        {/* Live Progress Bar when Processing */}
        {(isProcessing || progressPct > 0) && (
          <div className="space-y-2 pt-2 p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/30">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2">
                {isProcessing ? (
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                  </span>
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                )}
                <span>
                  {isProcessing
                    ? isPaused
                      ? "Batch paused"
                      : `Processing batch: ${processedCount} of ${totalCount} companies resolved...`
                    : "Batch run finished!"}
                </span>
              </span>
              <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                {progressPct}%
              </span>
            </div>

            <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-950 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-300 rounded-full shadow-sm"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        )}

        {/* Deep Lead Enrichment Option Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${enableEnrichment ? "bg-purple-500/10 text-purple-600 dark:text-purple-400" : "bg-slate-200 dark:bg-slate-800 text-slate-400"}`}>
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Deep Lead Enrichment (Phone, Email & Industry)</span>
                {enableEnrichment && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                    2-Step Pipeline Active
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Queries fallback contact snippets to strictly extract verified corporate Industry, Phone, and Email.
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={enableEnrichment}
              onChange={(e) => onToggleEnrichment(e.target.checked)}
              disabled={isProcessing}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-purple-600"></div>
          </label>
        </div>

        {/* Action Controls & Batch Tuning */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-2">
          {/* Main Execution Controls */}
          <div className="flex items-center gap-2.5 flex-wrap">
            {!isProcessing ? (
              <button
                onClick={onStart}
                disabled={lineCount === 0}
                className="px-6 py-2.5 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 rounded-xl transition-all shadow-md shadow-indigo-600/25 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer active:scale-[0.98]"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Extract & Verify Domains</span>
              </button>
            ) : (
              <>
                {isPaused ? (
                  <button
                    onClick={onResume}
                    className="px-4 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors flex items-center gap-2"
                  >
                    <Play className="w-4 h-4" />
                    <span>Resume</span>
                  </button>
                ) : (
                  <button
                    onClick={onPause}
                    className="px-4 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-200 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-2"
                  >
                    <Pause className="w-4 h-4" />
                    <span>Pause</span>
                  </button>
                )}

                <button
                  onClick={onStop}
                  className="px-4 py-2.5 text-sm font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 border border-rose-200 dark:border-rose-500/20 rounded-xl transition-colors flex items-center gap-2"
                >
                  <Square className="w-4 h-4" />
                  <span>Stop</span>
                </button>
              </>
            )}

            {processedCount > 0 && (
              <button
                onClick={onGoToResults}
                className="px-4 py-2 text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 border border-indigo-200 dark:border-indigo-800 rounded-xl transition-colors flex items-center gap-1.5"
              >
                <span>View Results ({processedCount})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Secondary Utilities & Settings Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowConfig(!showConfig)}
              className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800/70 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>Batch Tuning</span>
            </button>

            <button
              onClick={onClear}
              disabled={isProcessing}
              className="px-3 py-2 text-xs font-medium text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 bg-slate-100 dark:bg-slate-800/70 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Collapsible Batch Tuning Drawer */}
        {showConfig && (
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Chunk Size per Request
              </label>
              <select
                value={chunkSize}
                onChange={(e) => onChangeChunkSize(Number(e.target.value))}
                disabled={isProcessing}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-slate-200"
              >
                <option value={5}>5 companies / request</option>
                <option value={10}>10 companies / request (Recommended)</option>
                <option value={20}>20 companies / request (High speed)</option>
                <option value={25}>25 companies / request (Max)</option>
              </select>
              <p className="text-[11px] text-slate-400">
                Balances batch size with Gemini response latency.
              </p>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Concurrency Limit
              </label>
              <select
                value={concurrency}
                onChange={(e) => onChangeConcurrency(Number(e.target.value))}
                disabled={isProcessing}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-slate-200"
              >
                <option value={1}>1 worker (Serial)</option>
                <option value={2}>2 parallel workers</option>
                <option value={4}>4 parallel workers (Standard)</option>
                <option value={6}>6 parallel workers (Ultra fast)</option>
              </select>
              <p className="text-[11px] text-slate-400">
                Parallel search streams to speed up 50k batches.
              </p>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Delay Between Requests
              </label>
              <select
                value={delayMs}
                onChange={(e) => onChangeDelayMs(Number(e.target.value))}
                disabled={isProcessing}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-900 dark:text-slate-200"
              >
                <option value={0}>0ms (Immediate)</option>
                <option value={250}>250ms (Balanced)</option>
                <option value={500}>500ms (Safe rate-limit)</option>
                <option value={1000}>1000ms (Conservative)</option>
              </select>
              <p className="text-[11px] text-slate-400">
                Prevents Serper API HTTP 429 quota spikes.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
