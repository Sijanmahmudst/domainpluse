"use client";

import React, { useState } from "react";
import {
  KeyRound,
  ShieldCheck,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sliders,
  Plus,
  Trash2,
  RotateCcw,
  Sparkles,
  ExternalLink,
  Globe,
  Server,
  Zap,
  Code2,
  Bot,
  Settings,
} from "lucide-react";
import { DEFAULT_SHIELD_DOMAINS } from "@/lib/shield-domains";
import {
  UniversalApiConfig,
  ApiProviderId,
  SUPPORTED_API_PROVIDERS,
} from "@/lib/api-providers";

interface SettingsTabProps {
  apiConfig: UniversalApiConfig;
  onUpdateApiConfig: (config: UniversalApiConfig) => void;
  // Legacy Serper prop kept for convenience
  serperApiKey?: string;
  onUpdateSerperKey?: (key: string) => void;
  customGeminiApiKey: string;
  onUpdateCustomGeminiKey: (key: string) => void;
  strictness: number;
  onUpdateStrictness: (val: number) => void;
  shieldDomains: string[];
  onUpdateShieldDomains: (domains: string[]) => void;
}

export function SettingsTab({
  apiConfig,
  onUpdateApiConfig,
  customGeminiApiKey,
  onUpdateCustomGeminiKey,
  strictness,
  onUpdateStrictness,
  shieldDomains,
  onUpdateShieldDomains,
}: SettingsTabProps) {
  const [showApiKey, setShowApiKey] = useState(false);
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    valid: boolean;
    provider?: string;
    message: string;
    latency?: number;
    credits?: number;
  } | null>(null);

  const [shieldSearch, setShieldSearch] = useState("");
  const [newCustomDomain, setNewCustomDomain] = useState("");

  const currentProvider = SUPPORTED_API_PROVIDERS[apiConfig.provider] || SUPPORTED_API_PROVIDERS.serper;

  const handleProviderChange = (providerId: ApiProviderId) => {
    const meta = SUPPORTED_API_PROVIDERS[providerId];
    onUpdateApiConfig({
      ...apiConfig,
      provider: providerId,
      customEndpoint: apiConfig.customEndpoint || meta.defaultEndpoint,
    });
    setTestResult(null);
  };

  const handleTestConnection = async () => {
    if (!apiConfig.apiKey.trim()) {
      setTestResult({
        valid: false,
        message: "Please enter an API Key / Token before testing.",
      });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch("/api/api-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(apiConfig),
      });
      const data = await res.json();
      setTestResult(data);
    } catch (err: any) {
      setTestResult({
        valid: false,
        message: err.message || "Failed to reach test endpoint",
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleAddShieldDomain = () => {
    const clean = newCustomDomain
      .trim()
      .toLowerCase()
      .replace(/^https?:\/\//, "")
      .replace(/^www\./, "")
      .split("/")[0];
    if (!clean) return;
    if (!shieldDomains.includes(clean)) {
      onUpdateShieldDomains([...shieldDomains, clean]);
    }
    setNewCustomDomain("");
  };

  const handleRemoveShieldDomain = (domain: string) => {
    onUpdateShieldDomains(shieldDomains.filter((d) => d !== domain));
  };

  const handleResetShieldDomains = () => {
    onUpdateShieldDomains(DEFAULT_SHIELD_DOMAINS);
  };

  const filteredShieldDomains = shieldDomains.filter((d) =>
    d.toLowerCase().includes(shieldSearch.toLowerCase().trim())
  );

  return (
    <div className="space-y-6">
      <div className="border border-slate-200 dark:border-slate-800 rounded-3xl bg-white dark:bg-slate-900/40 p-5 sm:p-7 space-y-7 shadow-sm backdrop-blur">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Server className="w-5 h-5 text-indigo-500" />
            <span>Universal Search API Provider Gateway & Credentials</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Connect any Google scraping engine (Serper, Google CSE, Bright Data, Apify, or your internal REST search endpoint).
          </p>
        </div>

        {/* SECTION 1: Universal Provider Selector Cards */}
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Select Active Search Provider
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {Object.values(SUPPORTED_API_PROVIDERS).map((p) => {
              const isSelected = apiConfig.provider === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => handleProviderChange(p.id)}
                  className={`p-3 rounded-2xl border text-left transition-all relative cursor-pointer ${
                    isSelected
                      ? "border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/40 shadow-xs ring-1 ring-indigo-500"
                      : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-900/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold ${
                        isSelected
                          ? "text-indigo-900 dark:text-indigo-200"
                          : "text-slate-800 dark:text-slate-200"
                      }`}
                    >
                      {p.name}
                    </span>
                    {isSelected && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                    )}
                  </div>
                  <span className="inline-block mt-1 text-[9px] font-semibold px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                    {p.badge}
                  </span>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                    {p.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* SECTION 2: Provider Configuration Fields */}
        <div className="p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Configure {currentProvider.name}
              </h3>
            </div>
            {currentProvider.docsUrl !== "#" && (
              <a
                href={currentProvider.docsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 self-start sm:self-auto"
              >
                <span>Provider Docs</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* API Key / Token input */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {currentProvider.id === "google_cse"
                  ? "Google Cloud API Key"
                  : currentProvider.id === "apify"
                  ? "Apify API Token"
                  : currentProvider.id === "custom"
                  ? "API Key / Auth Secret"
                  : "API Key"}
              </label>
              <div className="relative">
                <input
                  type={showApiKey ? "text" : "password"}
                  value={apiConfig.apiKey}
                  onChange={(e) =>
                    onUpdateApiConfig({ ...apiConfig, apiKey: e.target.value })
                  }
                  placeholder={currentProvider.keyPlaceholder}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-slate-100 pr-10 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-3 top-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Google CSE Search Engine ID (cx) */}
            {currentProvider.requiresCseId && (
              <div className="space-y-1.5 md:col-span-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                  <span>Search Engine ID (cx)</span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    Create at cse.google.com with &quot;Search the entire web&quot; enabled
                  </span>
                </label>
                <input
                  type="text"
                  value={apiConfig.googleCseId || ""}
                  onChange={(e) =>
                    onUpdateApiConfig({ ...apiConfig, googleCseId: e.target.value })
                  }
                  placeholder="e.g. 0123456789abcdef:0a1b2c3d"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
            )}

            {/* Custom Endpoint URL & Method */}
            {currentProvider.requiresCustomEndpoint && (
              <>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Custom Endpoint URL
                  </label>
                  <input
                    type="url"
                    value={apiConfig.customEndpoint || ""}
                    onChange={(e) =>
                      onUpdateApiConfig({ ...apiConfig, customEndpoint: e.target.value })
                    }
                    placeholder="https://api.yourcompany.com/v1/search"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    HTTP Method & Header Key
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={apiConfig.customHttpMethod || "POST"}
                      onChange={(e) =>
                        onUpdateApiConfig({
                          ...apiConfig,
                          customHttpMethod: e.target.value as "GET" | "POST",
                        })
                      }
                      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                    >
                      <option value="POST">POST</option>
                      <option value="GET">GET</option>
                    </select>
                    <input
                      type="text"
                      value={apiConfig.customAuthHeader || "Authorization"}
                      onChange={(e) =>
                        onUpdateApiConfig({ ...apiConfig, customAuthHeader: e.target.value })
                      }
                      placeholder="Header (e.g. X-API-KEY or Authorization)"
                      className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Test Provider Connection Button */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
            <button
              onClick={handleTestConnection}
              disabled={isTesting}
              className="px-4 py-2 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer shadow-xs"
            >
              {isTesting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Pinging {currentProvider.name}...</span>
                </>
              ) : (
                <>
                  <Zap className="w-3.5 h-3.5" />
                  <span>Test {currentProvider.name} Connection</span>
                </>
              )}
            </button>

            <span className="text-[11px] text-slate-400">
              {apiConfig.apiKey
                ? `${currentProvider.name} key stored locally`
                : "No key supplied: Smart AI heuristic simulation active"}
            </span>
          </div>

          {/* Test Results Banner */}
          {testResult && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-center gap-2.5 animate-in fade-in duration-200 ${
                testResult.valid
                  ? "bg-emerald-50 dark:bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/20"
                  : "bg-rose-50 dark:bg-rose-500/10 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-500/20"
              }`}
            >
              {testResult.valid ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
              )}
              <div className="flex-1 flex flex-wrap items-center justify-between gap-2">
                <span>{testResult.message}</span>
                {testResult.latency !== undefined && (
                  <span className="font-mono text-[11px] font-semibold opacity-80">
                    Latency: {testResult.latency}ms
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* SECTION 3: Gemini AI Model Settings */}
        <div className="p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-500" />
              <span>Gemini AI Smart Validation & Title Matching</span>
              <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                Built-in Active
              </span>
            </label>
            <span className="text-[11px] font-mono text-purple-500 font-semibold">
              gemini-3.8-flash
            </span>
          </div>

          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            The server automatically uses <strong>gemini-3.8-flash</strong> for semantic page title matching (detecting <code>abc.xyz</code> for Alphabet, <code>meta.com</code> for Meta, <code>cat.com</code> for Caterpillar), plus strict anti-hallucination lead contact enrichment.
          </p>

          <div className="pt-2">
            <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
              Optional: Custom Gemini API Key override
            </label>
            <div className="relative mt-1">
              <input
                type={showGeminiKey ? "text" : "password"}
                value={customGeminiApiKey}
                onChange={(e) => onUpdateCustomGeminiKey(e.target.value)}
                placeholder="Leave empty to use built-in server Gemini API key"
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-slate-100 pr-10 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={() => setShowGeminiKey(!showGeminiKey)}
                className="absolute right-3 top-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 4: Strictness Threshold Slider */}
        <div className="p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-indigo-500" />
                <span>Verification Confidence Strictness Threshold</span>
              </span>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Results with an AI confidence score below this threshold are strictly marked as &quot;N/A&quot; to prevent inaccurate data.
              </p>
            </div>
            <span className="font-mono text-base font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
              {strictness}%
            </span>
          </div>

          <input
            type="range"
            min={40}
            max={95}
            step={5}
            value={strictness}
            onChange={(e) => onUpdateStrictness(Number(e.target.value))}
            className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 dark:bg-slate-800 rounded-lg"
          />

          <div className="flex justify-between text-[11px] text-slate-400 font-mono">
            <span>Permissive (40%)</span>
            <span>Balanced (70% - Recommended)</span>
            <span>Strict (95%)</span>
          </div>
        </div>

        {/* SECTION 5: 100+ Platform Shield Filter Manager */}
        <div className="p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>100+ Social Media & Directory Shield</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 tabular-nums">
                  {shieldDomains.length} domains active
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Automatically discards social profiles, review directories, wikis, and news aggregators from search results.
              </p>
            </div>

            <button
              onClick={handleResetShieldDomains}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 self-start sm:self-auto cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset to Defaults</span>
            </button>
          </div>

          {/* Add custom domain & search */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={newCustomDomain}
                onChange={(e) => setNewCustomDomain(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAddShieldDomain()}
                placeholder="Add custom domain to blacklist (e.g. somedirectory.org)"
                className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400"
              />
              <button
                onClick={handleAddShieldDomain}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>

            <input
              type="text"
              value={shieldSearch}
              onChange={(e) => setShieldSearch(e.target.value)}
              placeholder="Search blacklisted domains..."
              className="w-full sm:w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400"
            />
          </div>

          {/* Scrollable list of active shield tags */}
          <div className="max-h-48 overflow-y-auto p-3 rounded-xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 flex flex-wrap gap-1.5 text-xs">
            {filteredShieldDomains.length === 0 ? (
              <span className="text-slate-400 text-xs italic">
                No domains match &quot;{shieldSearch}&quot;
              </span>
            ) : (
              filteredShieldDomains.map((dom) => (
                <span
                  key={dom}
                  className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-mono border border-slate-200 dark:border-slate-700"
                >
                  <span>{dom}</span>
                  <button
                    onClick={() => handleRemoveShieldDomain(dom)}
                    className="text-slate-400 hover:text-rose-500 cursor-pointer"
                    title={`Remove ${dom} from blacklist`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </span>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
