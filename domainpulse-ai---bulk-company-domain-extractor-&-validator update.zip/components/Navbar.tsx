"use client";

import React from "react";
import {
  Globe,
  Sliders,
  TableProperties,
  Search,
  KeyRound,
  Download,
  Moon,
  Sun,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FolderKanban,
  Server,
} from "lucide-react";

export type NavTab = "extractor" | "results" | "playground" | "settings";

interface NavbarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  resultsCount: number;
  verifiedCount: number;
  hasSerperKey: boolean;
  isProcessing: boolean;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onDownloadStandalone: () => void;
  // Multi-list session props
  activeSessionName?: string;
  sessionCount?: number;
  onToggleSidebar?: () => void;
  providerName?: string;
}

export function Navbar({
  activeTab,
  onTabChange,
  resultsCount,
  isProcessing,
  theme,
  onToggleTheme,
  onDownloadStandalone,
  activeSessionName,
  sessionCount = 1,
  onToggleSidebar,
  providerName = "Serper.dev",
  hasSerperKey,
}: NavbarProps) {
  return (
    <header className="border-b border-slate-200 dark:border-slate-800/80 bg-white/90 dark:bg-slate-950/90 backdrop-blur sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3 md:gap-6">
        {/* Zone 1: Sidebar Toggle + Brand Wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title="Open Saved Batch Lists Sidebar"
            >
              <FolderKanban className="w-4 h-4 text-indigo-500" />
              <span className="hidden sm:inline text-xs font-semibold">Lists</span>
              {sessionCount > 0 && (
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {sessionCount}
                </span>
              )}
            </button>
          )}

          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center shadow-md shadow-indigo-500/20 text-white shrink-0">
            <Globe className="w-5 h-5" />
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
                DomainPulse{" "}
                <span className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                  AI
                </span>
              </span>
            </div>
            {activeSessionName && (
              <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[140px] sm:max-w-[200px] leading-none">
                {activeSessionName}
              </span>
            )}
          </div>
        </div>

        {/* Zone 2: Navigation Links / Segmented Tabs */}
        <nav className="hidden md:flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-xl text-sm">
          <button
            onClick={() => onTabChange("extractor")}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === "extractor"
                ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Sliders className="w-4 h-4 text-indigo-500 dark:text-indigo-200" />
            <span>Bulk Extractor</span>
            {isProcessing && (
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            )}
          </button>

          <button
            onClick={() => onTabChange("results")}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === "results"
                ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <TableProperties className="w-4 h-4 text-emerald-500 dark:text-emerald-300" />
            <span>Live Results</span>
            {resultsCount > 0 && (
              <span className="text-xs font-mono font-bold px-1.5 py-0.5 rounded-md bg-indigo-100 dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 tabular-nums">
                {resultsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onTabChange("playground")}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === "playground"
                ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Search className="w-4 h-4 text-purple-500 dark:text-purple-300" />
            <span>Quick Test</span>
          </button>

          <button
            onClick={() => onTabChange("settings")}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === "settings"
                ? "bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Server className="w-4 h-4 text-amber-500 dark:text-amber-300" />
            <span>Universal API & Shield</span>
          </button>
        </nav>

        {/* Zone 3: Live Status + Theme + Export Action */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Universal API Provider Status Pill */}
          <div
            onClick={() => onTabChange("settings")}
            className="cursor-pointer hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-indigo-400 transition-colors"
            title={`Active search provider: ${providerName}. Click to configure credentials.`}
          >
            {hasSerperKey ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            ) : (
              <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
            )}
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              {providerName}
            </span>
            <span className="text-slate-300 dark:text-slate-700">·</span>
            <span className="text-emerald-500 font-semibold">Gemini 3.8</span>
          </div>

          {/* Download Standalone HTML Button */}
          <button
            onClick={onDownloadStandalone}
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800/80 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors whitespace-nowrap cursor-pointer"
            title="Download single-file HTML version with embedded Universal API Gateway & SheetJS dual export"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Standalone HTML</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-600" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Tab Bar */}
      <div className="md:hidden border-t border-slate-200 dark:border-slate-800 px-3 py-2 flex items-center justify-around bg-slate-50 dark:bg-slate-900/80">
        <button
          onClick={() => onTabChange("extractor")}
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded cursor-pointer ${
            activeTab === "extractor"
              ? "bg-indigo-600 text-white"
              : "text-slate-600 dark:text-slate-400"
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Extract</span>
        </button>
        <button
          onClick={() => onTabChange("results")}
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded cursor-pointer ${
            activeTab === "results"
              ? "bg-indigo-600 text-white"
              : "text-slate-600 dark:text-slate-400"
          }`}
        >
          <TableProperties className="w-3.5 h-3.5" />
          <span>Results ({resultsCount})</span>
        </button>
        <button
          onClick={() => onTabChange("playground")}
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded cursor-pointer ${
            activeTab === "playground"
              ? "bg-indigo-600 text-white"
              : "text-slate-600 dark:text-slate-400"
          }`}
        >
          <Search className="w-3.5 h-3.5" />
          <span>Test</span>
        </button>
        <button
          onClick={() => onTabChange("settings")}
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded cursor-pointer ${
            activeTab === "settings"
              ? "bg-indigo-600 text-white"
              : "text-slate-600 dark:text-slate-400"
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Gateway</span>
        </button>
      </div>
    </header>
  );
}
