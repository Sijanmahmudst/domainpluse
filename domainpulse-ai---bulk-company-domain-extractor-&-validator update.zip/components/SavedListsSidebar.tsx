"use client";

import React, { useState } from "react";
import {
  FolderKanban,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  MoreVertical,
  Trash2,
  Edit2,
  Copy,
  Download,
  FileSpreadsheet,
  FileText,
  X,
  ChevronRight,
  Database,
  Sparkles,
  Layers,
} from "lucide-react";
import { CompanyListSession } from "@/lib/sessions";
import { exportToCSV, exportToExcel } from "@/lib/export-utils";

interface SavedListsSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: CompanyListSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onCreateNewSession: () => void;
  onRenameSession: (id: string, newName: string) => void;
  onDeleteSession: (id: string) => void;
  onDuplicateSession: (id: string) => void;
}

export function SavedListsSidebar({
  isOpen,
  onClose,
  sessions,
  activeSessionId,
  onSelectSession,
  onCreateNewSession,
  onRenameSession,
  onDeleteSession,
  onDuplicateSession,
}: SavedListsSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);

  const filteredSessions = sessions.filter((s) =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const handleStartRename = (session: CompanyListSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(session.id);
    setEditingName(session.name);
    setMenuOpenId(null);
  };

  const handleSaveRename = (id: string) => {
    if (editingName.trim()) {
      onRenameSession(id, editingName.trim());
    }
    setEditingId(null);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Mobile backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-40 md:hidden"
      />

      {/* Sidebar container */}
      <aside className="fixed top-16 bottom-0 left-0 z-40 w-80 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col shadow-2xl transition-all animate-in slide-in-from-left duration-200">
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border border-indigo-200 dark:border-indigo-800/80">
                <FolderKanban className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                  Saved Batch Lists
                </h3>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {sessions.length} {sessions.length === 1 ? "list" : "lists"} in history
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* New Batch Button */}
          <button
            onClick={() => {
              onCreateNewSession();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full py-2 px-3 text-xs font-semibold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Batch List</span>
          </button>

          {/* Search filter for lists */}
          {sessions.length > 3 && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search saved lists..."
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}
        </div>

        {/* Sessions Scrollable List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
          {filteredSessions.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400 px-4">
              <Database className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="font-medium text-slate-600 dark:text-slate-400">
                No matching lists found.
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Create a new batch or adjust your search filter.
              </p>
            </div>
          ) : (
            filteredSessions.map((session) => {
              const isActive = session.id === activeSessionId;
              const dateStr = new Date(session.createdAt).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
              });
              const timeStr = new Date(session.createdAt).toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
              });

              const isEditing = editingId === session.id;

              return (
                <div
                  key={session.id}
                  onClick={() => {
                    if (!isEditing) {
                      onSelectSession(session.id);
                      if (window.innerWidth < 768) onClose();
                    }
                  }}
                  className={`group relative p-3 rounded-xl border transition-all cursor-pointer ${
                    isActive
                      ? "bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800/80 shadow-xs ring-1 ring-indigo-500/20"
                      : "bg-white dark:bg-slate-900/60 border-slate-200 dark:border-slate-800/70 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    {/* Title or inline edit */}
                    <div className="flex-1 min-w-0">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editingName}
                          onChange={(e) => setEditingName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") handleSaveRename(session.id);
                            if (e.key === "Escape") setEditingId(null);
                          }}
                          onBlur={() => handleSaveRename(session.id)}
                          autoFocus
                          className="w-full text-xs font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-950 border border-indigo-500 rounded px-1.5 py-0.5 focus:outline-none"
                        />
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              session.status === "completed"
                                ? "bg-emerald-500"
                                : session.status === "processing"
                                ? "bg-indigo-500 animate-pulse"
                                : "bg-amber-400"
                            }`}
                          />
                          <h4
                            className={`text-xs font-bold truncate leading-snug ${
                              isActive
                                ? "text-indigo-900 dark:text-indigo-200"
                                : "text-slate-800 dark:text-slate-200"
                            }`}
                            title={session.name}
                          >
                            {session.name}
                          </h4>
                        </div>
                      )}

                      {/* Metadata tags */}
                      <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-500 dark:text-slate-400">
                        <span className="font-mono font-medium">
                          {session.stats.total || session.results.length} companies
                        </span>
                        <span>·</span>
                        {session.stats.verified > 0 && (
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            {session.stats.verified} verified
                          </span>
                        )}
                        <span>·</span>
                        <span className="flex items-center gap-1 text-slate-400">
                          <Clock className="w-2.5 h-2.5" />
                          {dateStr}
                        </span>
                      </div>
                    </div>

                    {/* Actions Menu */}
                    <div className="relative shrink-0" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() =>
                          setMenuOpenId(menuOpenId === session.id ? null : session.id)
                        }
                        className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="List options"
                      >
                        <MoreVertical className="w-3.5 h-3.5" />
                      </button>

                      {menuOpenId === session.id && (
                        <div className="absolute right-0 top-6 z-50 w-44 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-1 text-xs text-slate-700 dark:text-slate-300 animate-in fade-in zoom-in-95 duration-100">
                          <button
                            onClick={(e) => handleStartRename(session, e)}
                            className="w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Rename Batch</span>
                          </button>
                          <button
                            onClick={() => {
                              onDuplicateSession(session.id);
                              setMenuOpenId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5 text-purple-500" />
                            <span>Duplicate List</span>
                          </button>
                          <div className="border-t border-slate-100 dark:border-slate-800 my-1" />
                          <button
                            onClick={() => {
                              exportToCSV(session.results, `batch_${session.name.replace(/\s+/g, "_")}`);
                              setMenuOpenId(null);
                            }}
                            disabled={session.results.length === 0}
                            className="w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 disabled:opacity-40 cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5 text-slate-400" />
                            <span>Export as CSV</span>
                          </button>
                          <button
                            onClick={() => {
                              exportToExcel(session.results, `batch_${session.name.replace(/\s+/g, "_")}`);
                              setMenuOpenId(null);
                            }}
                            disabled={session.results.length === 0}
                            className="w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 disabled:opacity-40 cursor-pointer"
                          >
                            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
                            <span>Export as Excel (.xlsx)</span>
                          </button>
                          {sessions.length > 1 && (
                            <>
                              <div className="border-t border-slate-100 dark:border-slate-800 my-1" />
                              <button
                                onClick={() => {
                                  if (confirm(`Delete list "${session.name}"?`)) {
                                    onDeleteSession(session.id);
                                  }
                                  setMenuOpenId(null);
                                }}
                                className="w-full text-left px-3 py-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center gap-2 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Delete List</span>
                              </button>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
          <span className="flex items-center gap-1">
            <Database className="w-3 h-3 text-indigo-500" />
            <span>Persisted locally</span>
          </span>
          <span className="font-mono text-[10px] text-slate-400">
            {sessions.reduce((acc, s) => acc + (s.stats.total || 0), 0)} total queued
          </span>
        </div>
      </aside>
    </>
  );
}
