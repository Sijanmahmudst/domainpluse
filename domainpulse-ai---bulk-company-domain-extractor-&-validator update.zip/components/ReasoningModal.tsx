"use client";

import React, { useState } from "react";
import {
  X,
  Sparkles,
  CheckCircle2,
  XCircle,
  Globe,
  Briefcase,
  Phone,
  Mail,
  Copy,
  Check,
  ShieldCheck,
  Award,
  Layers,
} from "lucide-react";
import { ExtractedCompanyResult } from "@/app/api/domain-extract/route";

interface ReasoningModalProps {
  result: ExtractedCompanyResult | null;
  onClose: () => void;
}

export function ReasoningModal({ result, onClose }: ReasoningModalProps) {
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  if (!result) return null;

  const handleCopy = (text: string, label: string) => {
    if (!text || text === "N/A") return;
    navigator.clipboard.writeText(text);
    setCopiedItem(label);
    setTimeout(() => setCopiedItem(null), 2000);
  };

  const isTitleMatch = result.matchType === "TITLE_MATCH";
  const isExactMatch = result.matchType === "EXACT_MATCH";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5 text-xs animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Deep Search & Title Matching Audit
              </h3>
              <p className="text-[11px] text-slate-400">Gemini 3.8 Flash Semantic Matcher</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Semantic Title Match Banner */}
        {isTitleMatch && (
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-transparent border border-purple-500/20 text-purple-900 dark:text-purple-300 space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-xs">
              <Sparkles className="w-3.5 h-3.5 text-purple-500" />
              <span>Semantic Page Title & Snippet Match Verified</span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400">
              The domain slug differs from the brand name, but Gemini AI deeply analyzed the candidate Page Title and contextual snippet to authenticate the official website.
            </p>
          </div>
        )}

        {/* Company & Domain Card */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                Target Entity
              </span>
              <div className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                {result.company}
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {isTitleMatch ? (
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30">
                  <Sparkles className="w-3 h-3" />
                  TITLE MATCH ({result.confidence}%)
                </span>
              ) : isExactMatch ? (
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  EXACT MATCH ({result.confidence}%)
                </span>
              ) : result.matchType === "ENRICHED_ONLY" ? (
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                  LEADS ONLY
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-slate-500/15 text-slate-600 dark:text-slate-400 border border-slate-500/30">
                  <XCircle className="w-3.5 h-3.5" />
                  N/A
                </span>
              )}
            </div>
          </div>

          {/* Matched Details Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-200/60 dark:border-slate-800/60 text-xs">
            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">Verified Domain</div>
              <div className="font-mono font-bold text-slate-900 dark:text-slate-100 truncate">
                {result.extractedDomain || "N/A"}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">API Credit Billing</div>
              <div className="font-mono font-bold">
                {result.creditsUsed === 0 || !result.extractedDomain || result.extractedDomain === "N/A" ? (
                  <span className="text-emerald-600 dark:text-emerald-400">0 Free (Zero-Cost)</span>
                ) : (
                  <span className="text-amber-600 dark:text-amber-400">1 Credit Billed</span>
                )}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">Search Rank</div>
              <div className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                {result.matchedRank !== undefined
                  ? result.matchedRank === 0
                    ? "Knowledge Graph"
                    : `Rank #${result.matchedRank}`
                  : "N/A"}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">Candidates</div>
              <div className="font-mono font-bold text-slate-900 dark:text-slate-100 truncate">
                {result.candidatesEvaluated} organic
              </div>
            </div>
          </div>

          {/* Matched Webpage Title */}
          {result.matchedTitle && (
            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400 font-semibold uppercase">
                Matched Webpage Title:
              </div>
              <div className="font-medium text-slate-800 dark:text-slate-200 text-xs mt-0.5">
                &quot;{result.matchedTitle}&quot;
              </div>
            </div>
          )}

          {/* Contact Leads Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-xs">
            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">Industry</div>
              <div className="font-semibold text-slate-800 dark:text-slate-200 truncate" title={result.industry}>
                {result.industry || "N/A"}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">Phone Number</div>
              <div className="font-mono text-purple-600 dark:text-purple-400 font-bold truncate">
                {result.phone || "N/A"}
              </div>
            </div>

            <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400">Business Email</div>
              <div className="font-mono text-indigo-600 dark:text-indigo-400 font-bold truncate">
                {result.email || "N/A"}
              </div>
            </div>
          </div>
        </div>

        {/* AI Reasoning Text */}
        <div className="space-y-1.5">
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            Semantic Match Reasoning:
          </span>
          <div className="p-3.5 rounded-xl bg-slate-100/70 dark:bg-slate-950/90 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 leading-relaxed font-sans text-xs">
            {result.reasoning}
          </div>
        </div>

        {/* Search Snippet (if available) */}
        {result.serperSnippet && (
          <div className="space-y-1.5">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Selected Google Snippet Context:
            </span>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-400 italic">
              &quot;{result.serperSnippet}&quot;
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
