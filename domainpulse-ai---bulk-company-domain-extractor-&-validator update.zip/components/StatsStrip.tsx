"use client";

import React from "react";
import { CheckCircle2, XCircle, Gauge, Activity, Database, Mail, PhoneCall } from "lucide-react";

interface StatsStripProps {
  totalInQueue: number;
  processedCount: number;
  verifiedCount: number;
  enrichedCount: number;
  naCount: number;
  speedPerSec: number;
  etaSeconds: number | null;
  isProcessing: boolean;
  billedCredits?: number;
  zeroCostSearches?: number;
}

export function StatsStrip({
  totalInQueue,
  processedCount,
  verifiedCount,
  enrichedCount,
  naCount,
  speedPerSec,
  etaSeconds,
  isProcessing,
  billedCredits = 0,
  zeroCostSearches = 0,
}: StatsStripProps) {
  const successRate =
    processedCount > 0 ? Math.round((verifiedCount / processedCount) * 100) : 0;

  const formatETA = (secs: number | null) => {
    if (secs === null || secs <= 0) return "Ready";
    if (secs < 60) return `${secs}s remaining`;
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins}m ${rem}s remaining`;
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {/* 1. Queue size */}
      <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur transition-all">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Total Queue</span>
          <Database className="w-3.5 h-3.5 text-slate-400" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
          {totalInQueue.toLocaleString()}
        </div>
        <div className="text-[11px] text-slate-500 dark:text-slate-500 mt-0.5 truncate">
          {totalInQueue === 0 ? "No active list" : `${totalInQueue} entities`}
        </div>
      </div>

      {/* 2. Processed */}
      <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur transition-all">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Processed</span>
          <Activity className={`w-3.5 h-3.5 ${isProcessing ? "text-indigo-500 animate-pulse" : "text-slate-400"}`} />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400 mt-1">
          {processedCount.toLocaleString()}
        </div>
        <div className="text-[11px] text-slate-500 dark:text-slate-500 mt-0.5">
          {totalInQueue > 0
            ? `${Math.round((processedCount / totalInQueue) * 100)}% done`
            : "Awaiting start"}
        </div>
      </div>

      {/* 3. Verified Domains */}
      <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur transition-all">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Verified</span>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-1">
          {verifiedCount.toLocaleString()}
        </div>
        <div className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400/90 mt-0.5">
          {successRate}% verified
        </div>
      </div>

      {/* 4. Enriched Contact Leads */}
      <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur transition-all">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Enriched</span>
          <PhoneCall className="w-3.5 h-3.5 text-purple-500" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-purple-600 dark:text-purple-400 mt-1">
          {enrichedCount.toLocaleString()}
        </div>
        <div className="text-[11px] text-slate-500 dark:text-slate-500 mt-0.5 truncate">
          Phone / Email / Industry
        </div>
      </div>

      {/* 5. Billed API Credits (Conditional Zero-Cost Policy) */}
      <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur transition-all">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">API Credits</span>
          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-500 dark:text-amber-400 border border-amber-500/20">
            1:1 Plan
          </span>
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-amber-600 dark:text-amber-400 mt-1">
          {billedCredits.toLocaleString()}
        </div>
        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate" title={`${zeroCostSearches} zero-cost searches where domain was N/A`}>
          <span className="text-emerald-600 dark:text-emerald-400 font-medium">+{zeroCostSearches} Free</span> (0-cost N/A)
        </div>
      </div>

      {/* 6. Velocity & ETA */}
      <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur col-span-2 md:col-span-1 transition-all">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Velocity & ETA</span>
          <Gauge className="w-3.5 h-3.5 text-cyan-500" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-cyan-600 dark:text-cyan-400 mt-1">
          {speedPerSec.toFixed(1)}/s
        </div>
        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
          {isProcessing ? formatETA(etaSeconds) : "Idle"}
        </div>
      </div>
    </div>
  );
}
